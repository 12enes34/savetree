<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="allCSS.css">
    <title>Kitap Ekle</title>
    
    
<?php
session_start();
    ?>

<?php


// Oturumda kullanıcı kimliği var mı kontrol et
if (isset($_SESSION['ID'])) {
    // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
    $userId = $_SESSION['ID'];
    
    $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      
    $query = "SELECT * FROM kullanicilar WHERE ID = ?;";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);


    if ($result) {
        $userInfo = mysqli_fetch_assoc($result);

        if ($userInfo) {
            
           
        } else {
            echo 'Kullanıcı bilgileri bulunamadı.';
        }
    } else {
        echo 'Sorgu hatası: ' . mysqli_error($conn);
    }
}
?>
    <style>
        

        .containerBookAdd2 {
            font-family: 'Arial', sans-serif;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            margin: auto;
            
        }
        
        h2 {
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }


        label {
            margin-top: 10px;
        }

        input, select, button {
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            color: #000;
        }

        button {
            background-color: #4CAF50;
            color: #fff;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        #selectedImagesContainer img {
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        form input,
        form textarea {
            color: black;
        }


    </style>
</head>
<body>
<header>
        <div class="header">
            <div class="logo">
            <a href="index.php">
        <img id="logojpg" src="logo.png" alt="Logo">
    </a>
            </div>
            <div class="quote">
                What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another.
                Mahatma Gandhi
            </div>
            
<script>
    window.onresize = function() {
        var quoteDiv = document.getElementById("quote");
        if (window.innerWidth <= 600) {
            quoteDiv.innerText = "Save Tree";
        } else {
            quoteDiv.innerText = "What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another. Mahatma Gandhi";
        }
    };
</script>
            


            <div class="buttons-container">
                <button id='KullaniciGiris' class="CustomButton" onclick="handleButtonClick(1)">Kullanıcı Girişi</button>
                <button id='KayitOl' class="CustomButton" onclick="handleButtonClick(2)">Kayıt Ol</button>
                <button class="CustomButton" onclick="handleButtonClick(3)">Anasayfa</button>
                <?php
if (isset($_SESSION['ID'])) {

    if ($userInfo) {
        // Kullanıcı adı ve soyadını ekrana yazdır
       
        
        // Butonları tıklanamaz yap ve içlerine isim ve soyisim yaz
        echo '<script>';
        echo 'document.getElementById("KullaniciGiris").innerText = "'.htmlspecialchars($userInfo['Name']).' '.htmlspecialchars($userInfo['Surname']).'";';
        echo 'document.getElementById("KullaniciGiris").onclick = function() {
            window.location.href = "KullaniciAnaSayfa.php";
        };;';

        echo 'document.getElementById("KayitOl").innerText = "Cikis";';
        echo 'document.getElementById("KayitOl").onclick = function() {
            window.location.href = "Cikis.php";
        };;';

        echo '</script>';
    } else {
        echo 'Kullanıcı bilgileri bulunamadı.';
    }
}



?>
            </div>
        </div>
        
    </header>
    <div class="containerBookAdd2">
        <h2>Kitap Ekle</h2>
        <form action="AddBookWithImages.php" method="post" enctype="multipart/form-data">
            <label for="writer">Yazar:</label>
            <input type="text" name="writer" maxlength="255" required><br>

            <label for="publicationYear">Yayin Yili:</label>
            <input type="number" name="publicationYear" min="1800" max="2024" required><br>

            <label for="publicationNumber">Yayin Numarasi:</label>
            <input type="text" name="publicationNumber" pattern="\d*" title="Sadece sayı girişi yapabilirsiniz." maxlength="255" required><br>

            <label for="bookName">Kitap Adi:</label>
            <input type="text" name="bookName" maxlength="255" required><br>

            <label for="bookType">Kitap Türü:</label>
            <select name="bookType" required>
                
            </select><br>

            


            <label for="bookImages">Kitap Resimleri (Maksimum 4 adet):</label>
            <input type="file" name="bookImages[]" accept="image/*" onchange="handleFileSelect(this)" multiple required>
            <div id="selectedImagesContainer"></div>

            <button type="submit">Kitap Ekle</button>
        </form>
    </div>

    

    <script>
        var bookGenres = [
            "Otobiyografi", "Kisisel Anilar", "Hatiratlar", "Ask", "BilimKurgu", "Macera", "Polisiye",
            "Tarihi", "Fantastik", "Gerilim", "Kisa Hikayeler", "Uzun Hikayeler", "Gezi Anilari",
            "Seyahat Gunlukleri", "Dramatik", "Epik", "Lirik", "Modern", "Bilim insani", "Sanatci biyografsi",
            "Unlu Kisiler", "Dini Hikayeler", "Dini Yorum", "Ekonomi", "Felsefe", "Populer bilim", "Psikoloji",
            "Sosyoloji", "Teknoloji", "Tarih", "Klasik Masallar", "Fabl Masallar", "Fantastik Masallar",
            "Temel Ders Kitaplari", "Yabanci Dil Kitaplari", "Egitim Teknolojisi Kitaplari"
        ];

        var bookTypeSelect = document.querySelector('select[name="bookType"]');

        // Kitap türlerini dropdown listesine ekleyen döngü
        for (var i = 0; i < bookGenres.length; i++) {
            var option = document.createElement('option');
            option.value = bookGenres[i];
            option.text = bookGenres[i];
            bookTypeSelect.add(option);
        }

        function handleFileSelect(input) {
            var selectedImagesContainer = document.getElementById('selectedImagesContainer');
            selectedImagesContainer.innerHTML = ''; // Her seçimden önce içeriği temizle

            var files = input.files;
            var maxFileCount = 4;

            if (files.length > maxFileCount) {
                alert('Maksimum 4 resim seçebilirsiniz.');
                input.value = ''; // Seçilen dosyaları temizle
                return;
            }

            for (var i = 0; i < files.length; i++) {
                var img = document.createElement('img');
                img.src = URL.createObjectURL(files[i]);
                img.width = 100;
                img.height = 100;
                selectedImagesContainer.appendChild(img);
            }
        }



        function handleButtonClick(buttonType) {
        if (buttonType === 1) {
            
            window.location.href = "KullaniciGirisEkrani.php?newValue=Giris"; // Yönlendirilecek sayfanın URL'sini belirtin
        } else if (buttonType === 2) {
            window.location.href = 'kullaniciGirisEkrani.php?newValue=Kayit';
            
        } else if (buttonType === 3) {
            window.location.href = 'index.php';
            
        }
        
        

    }
    </script>
</body>
</html>
