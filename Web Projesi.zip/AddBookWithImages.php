<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .CorrectFormUploded {
        color: white;
        background-color: #28a745;
        border-color: #f5c6cb;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid transparent;
        border-radius: 0.25rem;
    }
    .error-message {
        color: red;
        background-color: #f8d7da;
        border-color: #f5c6cb;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid transparent;
        border-radius: 0.25rem;
    }
    .error-message3 {
        color: red;
        background-color: #f8d7da;
        border-color: #f5c6cb;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid transparent;
        border-radius: 0.25rem;
    }
</style>

</head>
<body>


<?php
session_start();

if (isset($_SESSION['ID'])) {
    $BookOwnerID = $_SESSION['ID'];

   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  
// Formdan gelen verileri güvenli bir şekilde al
$writer             = mysqli_real_escape_string($conn, trim($_POST['writer']));
$publicationYear    = mysqli_real_escape_string($conn, trim($_POST['publicationYear']));
$publicationNumber  = mysqli_real_escape_string($conn, trim($_POST["publicationNumber"]));
$bookName           = mysqli_real_escape_string($conn, trim($_POST['bookName']));
$bookType           = mysqli_real_escape_string($conn, trim($_POST['bookType']));

$query = "INSERT INTO kitaplar (BookOwnerID, Writer, PublicationYear, PublicationNumber, BookName, BookType) 
          VALUES ('$BookOwnerID', '$writer', '$publicationYear', '$publicationNumber', '$bookName', '$bookType')";

$result = mysqli_query($conn, $query);

    if ($result) {
        $BookID = mysqli_insert_id($conn);

        if (isset($_FILES['bookImages'])) {
            $bookImagesArray = $_FILES['bookImages'];

            for ($i = 0; $i < count($bookImagesArray['name']); $i++) {
                $hata = $bookImagesArray['error'][$i];

                if ($hata != 0) {
                    echo 'Resim {$i + 1} yüklenirken bir hata gerçekleşti. Hata Kodu: $hata';
                } else {
                    $bookImagesBoyutu = $bookImagesArray['size'][$i];

                    if ($bookImagesBoyutu > (1024 * 1024 * 2)) {
                        echo 'Resim {'.$i + 1 .' } 2MB den büyük olamaz.';
                    } else {
                        $tip = $bookImagesArray['type'][$i];
                        $bookImagesAdi = $bookImagesArray['name'][$i];

                        $uzantisi = pathinfo($bookImagesAdi, PATHINFO_EXTENSION);
                        $yeni_adi = 'upload/' . time() . '_{'.$i.'_'.$BookOwnerID.'_'.$BookID.'}.' . $uzantisi;//ilk degisken yani $i resim indexi 2ci degisken yani $BookOwnerID kitap sahibinin id si 3cu olan ise yani $BookID  kitab id

                        if ($tip == 'image/jpeg' || $tip == 'image/png') {
                            if (move_uploaded_file($bookImagesArray['tmp_name'][$i], $yeni_adi)) {
                                echo "<div class='CorrectFormUploded'>Resim ".$i + 1 ." başarılı bir şekilde yüklendi.</div>";
                            } else {
                                echo "<div class='error-message'> Resim ".$i + 1 ." yüklenirken bir hata oluştu.</div>";
                            }
                        } else {
                            echo "<div class='error-message3'>Resim " . ($i + 1) . " sadece JPG ve PNG formatında olabilir.</div>";
                        }
                    }
                }
            }
        } else {
            echo 'Resim gönderilmedi.';
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo 'Kullanıcı girişi yapılmamış.';
}
mysqli_close($conn);
header('Location: KullaniciAnaSayfa.php');
exit; // Yönlendirme yaptıktan sonra kodun devamını çalıştırmamak için exit kullanın.
?>
    
    </body>
</html>