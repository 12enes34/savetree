<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Kayıt Formu</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#username').keyup(function(){
                var username = $(this).val();
                $.post('kontrol.php', {'username':username}, function(data){
                    $('#usernameMesaj').html(data);
                });
            });
        });
    </script>
</head>
<body>
    <h2>Kullanıcı Kayıt Formu</h2>
    <form action="kayit.php" method="POST">
        <label for="username">Kullanıcı Adı:</label><br>
        <input type="text" id="username" name="username" required><br>
        <span id="usernameMesaj"></span><br> <!-- Bu span, kullanıcı adı kontrol mesajlarını gösterecek -->
        
        <label for="email">E-posta Adresi:</label><br>
        <input type="email" id="email" name="email" required><br>
        
        <label for="password">Şifre:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        
        <button type="submit">Kayıt Ol</button>
    </form>
</body>
</html>
