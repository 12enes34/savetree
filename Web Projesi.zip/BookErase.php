<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .CorrectFormUploded {
        color: white;
        background-color: #28a745;
        border-color: #f5c6cb;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid transparent;
        border-radius: 0.25rem;
    }
    .error-message {
        color: red;
        background-color: #f8d7da;
        border-color: #f5c6cb;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid transparent;
        border-radius: 0.25rem;
    }
    </style>
</head>
<body>
    

<?php 
$conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  
if (!$conn) {
    die('Veritabanına bağlanırken hata oluştu: ' . mysqli_connect_error());
}

$BookID = mysqli_real_escape_string($conn, trim($_GET['BookID']));

$query = 
"DELETE FROM kitaplar WHERE ID = '$BookID'";
$result = mysqli_query($conn, $query);


if ($result) {
    echo "<div class='CorrectFormUploded'>Kitap başarıyla silindi.</div>";

    $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");
    $query = 
    "DELETE FROM takastalebi WHERE BookID = '$BookID'";
    $result = mysqli_query($conn, $query);
    if ($result) {
    echo "<div class='CorrectFormUploded'>Kitaba ait takas talepleri başarıyla silindi.</div>";
} else {
    echo "<div class='error-message'>Takas talepleri silinirken bir hata oluştu: " . mysqli_error($conn) . "</div>";
}



} else {
    echo "<div class='error-message'> Kitap silinirken bir hata oluştu: " . mysqli_error($conn). "</div>";
}

$uploadDirectory = 'upload/';
$uploadedImages = scandir($uploadDirectory);

foreach ($uploadedImages as $image) {
    if ($image != '.' && $image != '..') {
        // '{' karakterinin konumunu bul
        $accoladePosition = strpos($image, '{');

        if ($accoladePosition !== false) {
            // '{' karakterinden sonraki kısmı al
            $sonrakiKisim = substr($image, $accoladePosition + 1);

            // '}' karakterinin konumunu bul
            $kapatmaKarakteriPosition = strpos($sonrakiKisim, '}');

            if ($kapatmaKarakteriPosition !== false) {
                // '{' ve '}' arasındaki kısmı al
                $aradakiKisim = substr($sonrakiKisim, 0, $kapatmaKarakteriPosition);

                // '_' karakterine göre ayır
                $parcalanan = explode('_', $aradakiKisim);

                // Değerleri değişkenlere ata
                $resimIndex = $parcalanan[0];
                $BookOwnerID = $parcalanan[1];
                $BookID2 = $parcalanan[2];

                // Değerleri ekrana bastır
                echo 'Resim Index: ' . $resimIndex . '<br>';
                echo 'Book Owner ID: ' . $BookOwnerID . '<br>';
                echo 'Book ID: ' . $BookID2 . '<br>';
                if($BookID == $BookID2){
                // dosya yoluna gore siliyor
                $file = $uploadDirectory . $image;
                unlink($file);
                }

            } else {
                echo 'Metin içinde "}" karakteri bulunamadı.';
            }
        } else {
            echo 'Metin içinde "{" karakteri bulunamadı.';
        }
    }
}



mysqli_close($conn);
header("refresh:1;url=KullaniciAnaSayfa.php");
?>

</body>
</html>