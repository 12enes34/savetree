<?php
session_start(); // Oturumu başlat

// Oturumu sonlandır
session_unset(); // Tüm oturum değişkenlerini temizle
session_destroy(); // Oturumu sonlandır

// Ana sayfaya yönlendir
header("Location: index.php");
exit();
?>