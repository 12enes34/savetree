<?php
session_start(); // Oturumu başlat
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


if (!empty($_GET['token'])) {
    $tokenControl = htmlspecialchars($_GET['token']);
    echo '9 work';

    // Oturum değişkenlerine erişim
if (isset($_SESSION['ID'])) {
    $userID = $_SESSION['ID']; // Kullanıcı ID'sini al
    echo "Kullanıcı ID: " . $userID;
    if (isset($_SESSION['token'])) {
        
        $token = $_SESSION['token']; // Token değerini al
        if($token == $tokenControl){
        echo "Token: " . $token;






// $token değişkeni şimdi güvenli bir şekilde alınmış veya varsayılan değere sahip.





           $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");              
           session_start();
       
            // Formdan gelen verileri al

            // $username = mysqli_real_escape_string($conn, $_POST['username']);
            // $mail = mysqli_real_escape_string($conn, $_POST['mail']);
            // $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
            // $name = mysqli_real_escape_string($conn, $_POST['name']);
            // $surname = mysqli_real_escape_string($conn, $_POST['surname']);
            // $number = mysqli_real_escape_string($conn, $_POST['number']);
            // $city = mysqli_real_escape_string($conn, $_POST['city']);
            
            $username = 'afghjvcasdasdv';
            $mail = 'enes12_34@hotmail.com';
            $password = 'a';
            $name = 'a';
            $surname = 'a';
            $number = '901111';
            $city ='a';

            // SQL sorgusu oluştur
$query = "INSERT INTO kullanicilar (Username, Mail, Password, Name, Surname, PhoneNumber, City) 
VALUES (?, ?, ?, ?, ?, ?, ?)";

// Hazırlıklı ifadeyi hazırla
$stmt = mysqli_prepare($conn, $query);

// Bağlantı ve sorgu başarılıysa devam et
if ($stmt) {
// Parametreleri bağla
mysqli_stmt_bind_param($stmt, "sssssss", $username, $mail, $password, $name, $surname, $number, $city);

// Sorguyu çalıştır
mysqli_stmt_execute($stmt);

// İşlem başarılıysa mesajı göster
if (mysqli_stmt_affected_rows($stmt) > 0) {
echo "Kullanıcı başarıyla kaydedildi.";
} else {
echo "Kullanıcı kaydedilirken bir hata oluştu.";
}

// İfadenin bağlantısını kapat
mysqli_stmt_close($stmt);
} else {
echo "Hazırlıklı ifade hazırlanırken bir hata oluştu.";
}

sleep(2);
header("Location: kullaniciGirisEkrani.php");
 

}else {
    echo "Token eslesmiyor.";
}


} else {
    echo "Token bulunamadı.";
}
} else {
echo "Kullanıcı ID bulunamadı.";
}






} else {
    // $_GET['token'] dolu değilse veya boş ise, varsayılan bir değer atayabiliriz.
   



require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

// Şifre sıfırlama bağlantısı oluştur
$token = bin2hex(random_bytes(32));



$mail = new PHPMailer(true);
try {
 //Server settings
 $mail->CharSet = 'UTF-8';
 $mail->SMTPDebug = 0; // debug on - off 2 yada 3 ile detayli bilgi doner
 $mail->isSMTP(); 
 $mail->Host = 'smtp-mail.outlook.com'; // SMTP sunucusu örnek : mail.alanadi.com
 $mail->SMTPAuth = true; // SMTP Doğrulama
 $mail->AuthType = 'CRAM-MD5';
 $mail->Username = 'whaf5@hotmail.com'; // Mail kullanıcı adı
 $mail->Password = 'xenesx1234'; // Mail şifresi
 $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
 $mail->Port = 587; // SMTP Port
 $mail ->Timeout = 300; // ne kadar süre denensin gönderme işlemi?  
 $mail->SMTPOptions = array(
 'ssl' => array(
 'verify_peer' => false,
 'verify_peer_name' => false,
 'allow_self_signed' => true
 )
);
$UserMail = $_POST['email'];
echo $UserMail,'alooo';

$conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");   

    $query = "SELECT ID FROM kullanicilar WHERE Mail = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $UserMail);//"s" string , "i": Tam sayı (integer) , "d": Ondalık sayı (double) , "b": Blob (binary large object)
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);


        if ($row = mysqli_fetch_assoc($result)) {
            $id = $row['ID']; // Kullanıcı ID'sini al
        } else {
            // Kullanıcı bulunamadıysa hata mesajı göster ve işlemi sonlandır
            echo "Kullanıcı bulunamadı.";
            exit;
        }


$_SESSION['ID'] = $id;

// Başka bir değişkeni oturum değişkenine atama
$_SESSION['token'] = $token;

        // <?php echo htmlspecialchars($_GET['token']); 

$mesaj = "Merhaba, mailininizi onaylamak için aşağıdaki bağlantıya tıklayın:\n\n";
$mesaj .= "http://localhost/Web%20Projesi/EpostaOnayiTest.php?token=" . $token . "&id=" . $id;
//Alıcılar
 $mail->setfrom('whaf5@hotmail.com', 'İletişim Formu'); //mail gonderen mail adresi
 $mail->addAddress($_POST['email']);//hedef mail adresi
 $mail->addReplyTo($_POST['email'],'test name kismi');
 //İçerik
 $mail->isHTML(true);
 $mail->Subject = 'İletişim Formu.';
 $mail->Body = $mesaj;

 $mail->send();
  // Mesaj gönderme işlemi başarılıysa
  echo '<div class="success-message">';
  echo 'Mesajınız başarıyla iletilmiştir: ' . htmlspecialchars($_POST['email']);
  echo '</div>';
} catch (Exception $e) {
// Mesaj gönderme işlemi başarısızsa
echo '<div class="error-message">';
echo 'Mesajınız iletilirken bir hata oluştu: ' . $mail->ErrorInfo;
echo '</div>';}
}
// sifremi unuttuma basinca once mail adresini girmen isteniyor, gonderildigine dair mesaj yazan bir ekran , Mail geliyor sifreyi sifirlamk icin tiklayin diye , tiklayinca yeni parola girme ekranina atiyor
?>
