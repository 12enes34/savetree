<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-posta Onayı Formu</title>
</head>
<body>
    <h2>E-posta Onayı Formu</h2>
    <form action="EpostaOnayiTest.php" method="post">
        <label for="email">E-posta Adresi:</label><br>
        <input type="email" id="email" name="email" value="enes12_34@hotmail.com"><br><br>
        <input type="submit" value="Gönder">
    </form>
</body>
</html>


<?php 
$email = 'enes12_34@hotmail.com';
echo $email;
//header('Location: EpostaOnayiTest.php?email='.$email);
//exit; // Yönlendirme yaptıktan sonra kodun devamını çalıştırmamak için exit kullanın.

?>   
