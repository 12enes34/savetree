<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yatay Bölünmüş HTML</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Brush+Script&display=swap">

 

    
<?php
session_start();
    ?>

<?php


// Oturumda kullanıcı kimliği var mı kontrol et
if (isset($_SESSION['ID'])) {
    // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
    $userId = $_SESSION['ID'];
    
   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      $query = "SELECT Name, Surname FROM kullanicilar WHERE ID = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        $userInfo = mysqli_fetch_assoc($result);

        if ($userInfo) {
            
           
        } else {
            echo 'Kullanıcı bilgileri bulunamadı.';
        }
    } else {
        echo 'Sorgu hatası: ' . mysqli_error($conn);
    }
}
?>


<style>

.top {
    width: 75%;
    margin:auto;
    text-align: center;
    text-align-last: center;
    margin-top:25px; 
    display: flex;
    justify-content: center;
    align-items: center;
    
}


        body {
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            height: 100vh;
            
        }

        .container {
            flex: 1;
            display: flex;
        }

        .left, .right {
            flex: 1;
            
            box-sizing: border-box;
            padding: 20px;
        }

        .top, .bottom {
            flex: 1;
            display: flex;
        }

        .top-left, .top-right, .bottom-left, .bottom-right {
            flex: 1;
            
            box-sizing: border-box;
            
        }


        .top-right{

          margin-left: 10px;
    margin-right: 10px;
    margin-bottom: 10px;
    padding: 100px;
        }



        .top-left{
            
            display: inline-block;
            font: 19px sans-serif;
            margin: 0 auto;
            position: relative;
            width: 100%;
            max-width: 260px;
            height: 400px;
            overflow: hidden;
            border: 2px solid #ccc;
            white-space: nowrap;

            margin-left: 25%;
            margin-right:10px;
            margin-bottom: 10px;
            margin-top: 5%;

        }


      

        .Down {
   
    display: block; 
    font: 19px sans-serif;
    margin: 0 auto;
    position: relative;
    width: 70%;
    min-height: 20%;
    overflow: hidden;
    
    white-space: nowrap;

    margin-left: auto; 
    margin-right: auto;
    margin-bottom: 0px;
    margin-top: 0%;
}






.swiper {
    width: 256px;
    height: 400px;
  }

  .swiper-slide {
    text-align: center;
    font-size: 18px;
    background: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .swiper-slide img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .slider-container {
    display: inline-block;
    font: 19px sans-serif;
    margin: 0 auto;
    position: relative;
    width: 100%;
    max-width: 256px;
    height: 400px;
    overflow: hidden;
    border: 2px solid #ccc;
    white-space: nowrap;

    margin-left: 25%;
    margin-right:10px;
    margin-bottom: 10px;
    margin-top: 5%;
    transition: transform 0.3s;

    
  }


  .slider-container:hover {
    transform: scale(1.1); 
    }


  .slayt {
    display: inline-block;
    width: 100%;
    box-sizing: border-box;
  }
  
  .slayt img{
    width: 256px;;
    height: 420px;
  }   
  
  .controls {
    position: absolute; 
    bottom: 205px; 
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    display: flex;
    justify-content: space-between;
    z-index: 1; 
    user-select: none;
  }
  
  .slider-forward,
  .slider-back {
    background-color: transparent;
    color: #006aff;
    text-decoration: none;
    cursor: pointer;
    font-size: 30px;  
  }
  
  .slider-back {
    text-align: left;
  }
  
  .slider-forward {
    text-align: right;
  }
  @import url('https://fonts.googleapis.com/css?family=Brush+Script+MT');
  .BookName{
            font-size: 55px;
            color: #555;
            text-align: justify;
            font-family: 'Brush Script MT', cursive;
            
            margin: 0;
            padding: 0;
            line-height: 1;
        }

  .BookWriter{
            font-size: 55px;
            color: #555;
            text-align: justify;
            font-family: 'Brush Script MT', cursive;
            
            margin: 0;
            padding: 0;
            line-height: 1;
        }
  .BookYear{
            font-size: 55px;
            color: #555;
            text-align: justify;
            font-family: 'Brush Script MT', cursive;
            
            margin: 0;
            padding: 0;
            line-height: 1;
  }
  .BookNumber{ 
            font-size: 55px;
            color: #555;
            text-align: justify;
            font-family: 'Brush Script MT', cursive;
          
            margin: 0;
            padding: 0;
            line-height: 1;
  }

  




  
header img {
    width: 20px;
    height: auto;
    margin-top: 0px;
}




.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #333;
    color: #fff;
}


.logo{
    display: inline-block;
    padding: 0.5%;
    
    }


    #logojpg{
    width: 128px;
}


.quote {
    flex-grow: 1;
    margin: 0 20px;
    font-size: 28px;
    text-align: justify;
}

.buttons-container {
    text-align: center;
    display: block;
}


.CustomButton {
    padding: 10px;
    margin: 5px;
    font-size: 14px;
    cursor: pointer;
    background-color: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 12%; /* Yuvarlak şekil */
    text-align: center;
    position: relative; /* Animasyon için */
    overflow: hidden; /* Animasyon için */
}

.CustomButton {
    background-color: #3e3a3a;
}

.CustomButton:hover {
    background-color: #45a049;
    transform: scale(1.1); /* Büyüme efekti */
}

.CustomButton::before {
    content: ""; /* Animasyon için */
    position: absolute; /* Animasyon için */
    width: 100%; /* Animasyon için */
    height: 100%; /* Animasyon için */
    top: 0; /* Animasyon için */
    left: 0; /* Animasyon için */
    background: radial-gradient(circle, transparent 1%, #fff 15%); /* Animasyon için */
    transform: translateX(-150%); /* Animasyon için */
    transition: all 0.5s; /* Animasyon için */
}

.CustomButton:hover::before {
    transform: translateX(150%); /* Animasyon için */
}

.CustomButton::after {
    content: ""; /* İkon için */
    position: absolute; /* İkon için */
    width: 20px; /* İkon için */
    height: 20px; /* İkon için */
    top: 50%; /* İkon için */
    left: 50%; /* İkon için */
    transform: translate(-50%, -50%); /* İkon için */
    background-image: url("lock.png"); /* İkon için */
    background-size: cover; /* İkon için */
}

.CustomButton::after {
    background-image: url("plus.png"); /* İkon için */
}


#Trade{

  font-size: 34px;

}
#Trade:hover{background-color: #a07b45;}


*::selection {
    background-color: transparent;
    color: inherit;
}
/* Genel stiller burada */

/* Tablet ve üzeri ekranlar için stiller 
@media only screen and (min-width: 600px) {
    // Tablet ve üzeri ekranlar için özel stiller buraya gelecek 
    .left {
        flex-direction: row;
    }
    .top {
        width: 50%;
    }
    .Down {
        width: 50%;
    }
}
*/

/* Mobil cihazlar için stiller */
@media only screen and (max-width: 1400px) {
    /* Mobil cihazlar için özel stiller buraya gelecek */
    .left, .right {
        width: 100%;
    }
    .top, .Down {
        width: 100%;
        margin: 10px 0;
        flex-direction: column;
        display: flex;
    justify-content: center;
    align-items: center;
    }
    .top-left, .top-right, .bottom-left, .bottom-right {
        margin: 0 auto;
        width: 100%;
    }
    .slider-container {
        margin-left: 0;
    }
    .swiper {
        width: 100%;
        height: auto;
    }
    .BookName, .BookWriter, .BookYear, .BookNumber {
        font-size: 24px;
    }
    .CustomButton {
        font-size: 16px;
        padding: 8px;
        margin: 5px;
    }
}



    </style> 
</head>
<body>
<header>
        <div class="header">
            <div class="logo">
            <a href="index.php">
        <img id="logojpg" src="logo.png" alt="Logo">
    </a>
            </div>
            <div class="quote">
                What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another.
                Mahatma Gandhi
            </div>
            
<script>
    window.onresize = function() {
        var quoteDiv = document.getElementById("quote");
        if (window.innerWidth <= 600) {
            quoteDiv.innerText = "Save Tree";
        } else {
            quoteDiv.innerText = "What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another. Mahatma Gandhi";
        }
    };
</script>
            


            <div class="buttons-container">
                <button id='KullaniciGiris' class="CustomButton" onclick="handleButtonClick(1)">Kullanıcı Girişi</button>
                <button id='KayitOl' class="CustomButton" onclick="handleButtonClick(2)">Kayıt Ol</button>
                <button class="CustomButton" onclick="handleButtonClick(3)">Anasayfa</button>
                
                
                <?php


if (isset($_SESSION['ID'])) {

    if ($userInfo) {
        // Kullanıcı adı ve soyadını ekrana yazdır
       
        
        // Butonları tıklanamaz yap ve içlerine isim ve soyisim yaz
        echo '<script>';
        echo 'document.getElementById("KullaniciGiris").innerText = "'.$userInfo['Name'].' '.$userInfo['Surname'].'";';
        echo 'document.getElementById("KullaniciGiris").onclick = function() {
          window.location.href = "KullaniciAnaSayfa.php";
      };;';


        echo 'document.getElementById("KayitOl").innerText = "Cikis";';
        echo 'document.getElementById("KayitOl").onclick = function() {
            window.location.href = "Cikis.php";
        };;';

        echo '</script>';
    } else {
        echo 'Kullanıcı bilgileri bulunamadı.';
    }
}



?>
            </div>
        </div>
        
    </header>












    <div class="left">
            
            
            <div class="top">

                <div class="slider-container">
                    <div class="swiper mySwiper">
                        <div class="swiper-wrapper">
                        
                          
                          <?php
                              $BookID = trim($_GET['BookID']);


                              $uploadDirectory = 'upload/';
                              $uploadedImages = scandir($uploadDirectory);
                              

                              foreach ($uploadedImages as $image) {

                                if ($image != '.' && $image != '..') {
                            
                                    // '{' karakterinin konumunu bul
                                    $accoladePosition = strpos($image, '{');
                            
                                    if ($accoladePosition !== false) {
                                        // '{' karakterinden sonraki kısmı al
                                        $sonrakiKisim = substr($image, $accoladePosition + 1);
                            
                                        // '}' karakterinin konumunu bul
                                        $kapatmaKarakteriPosition = strpos($sonrakiKisim, '}');
                            
                                        if ($kapatmaKarakteriPosition !== false) {
                                            // '{' ve '}' arasındaki kısmı al
                                            $aradakiKisim = substr($sonrakiKisim, 0, $kapatmaKarakteriPosition);
                            
                                            // '_' karakterine göre ayır
                                            $parcalanan = explode('_', $aradakiKisim);
                            
                                            // Değerleri değişkenlere ata
                                            $resimIndex = $parcalanan[0];
                                            $BookOwnerID = $parcalanan[1];
                                            $BookIDFind = $parcalanan[2];

                                            if($BookID == $BookIDFind){
                                            echo '<div class="swiper-slide"><img src="' . $uploadDirectory . $image . '" alt=""></div>';
                                            }

                                          
                            
                                            // Değerleri ekrana bastır
                                           
                                        } else {
                                            echo 'Metin içinde "}" karakteri bulunamadı.';
                                        }
                                    } else {
                                        echo 'Metin içinde "{" karakteri bulunamadı.';
                                    }
                                
                                    
                                
                                
                                
                                }
                            }
                              





















































                          
                          ?>

                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
                    
                
                <div class="top-right">

                          <?php
                          
                              


                             $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                                $query = "SELECT * FROM kitaplar WHERE ID = ?";
                              $stmt = mysqli_prepare($conn, $query);
                              mysqli_stmt_bind_param($stmt, "i", $BookID);
                              mysqli_stmt_execute($stmt);
                              $result = mysqli_stmt_get_result($stmt);
                              $row = mysqli_fetch_assoc($result);

                          



                              $KitapID =$row['ID'];
                              $KitapSahibiID = $row["BookOwnerID"];

                              
                              
                                if ($result){
                                  
                                  $KitapID =$row['ID'];
                                  $KitapSahibiID = $row["BookOwnerID"];
                                  echo '<p class="BookName">'.$row["BookName"].'</p>
                                  <p class="BookWriter">Yazar: '.$row["Writer"].'</p>
                                  <p class="BookYear">Basim yili: '.$row["PublicationYear"].'</p>
                                  <p class="BookNumber">Basim numarasi: '.$row["PublicationNumber"].'</p>';
                                  
                                     if (isset($_SESSION['ID'])) {
                                     // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
                                    $ReciverId = $_SESSION['ID'];//talep edenin id si
                                   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  
                                    // SQL sorgusunu hazırlayın
                                    $query = "SELECT * FROM takastalebi WHERE BookGiverID = ? AND BookReceivedID = ? AND BookID = ?";
                                    $stmt = mysqli_prepare($conn, $query);
                                    
                                    // Değişkenleri bağlayın ve sorguyu çalıştırın
                                    mysqli_stmt_bind_param($stmt, "iii", $KitapSahibiID, $ReciverId, $KitapID);
                                    mysqli_stmt_execute($stmt);
                                    $result = mysqli_stmt_get_result($stmt);
                                     }
                                    



                                  if(!(empty($userId))){

                                  if(!($KitapSahibiID == $userId)){

                                    if (mysqli_num_rows($result) > 0) {
                                      echo '<button class="CustomButton" id="Trade" onclick="" disable >Boyle bir talep var zaten</button>';
                                      
                                    }

                                    else{echo '<button class="CustomButton" id="Trade" onclick="handleButtonClick(4)">Takas</button>';}
                                  }
                                  
                                  else{
                                    echo '<button class="CustomButton" id="Trade" onclick="" disable >Sahibi Sizsiniz</button>';

                                  }
                                }
                                else{
                                  echo '<button class="CustomButton" style="font-size: 26px;" id="Trade" onclick="" disable >Takas yapmak icin hesap acin yada giris yapin</button>';

                                }
                                }
                              
                            



                            echo '
                  
                            </div>
                        </div>
                </div>
            
                    <div class="Down">';
                      









  

                             $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                                $query = "SELECT * FROM kullanicilar WHERE ID = ?";
                              $stmt = mysqli_prepare($conn, $query);
                              mysqli_stmt_bind_param($stmt, "i", $KitapSahibiID);
                              mysqli_stmt_execute($stmt);
                              $result = mysqli_stmt_get_result($stmt);
                              
                              if ($result) {
                                $row = mysqli_fetch_assoc($result);
                                $BookOwnerUsername = $row["Username"];
                                  
                                echo '
                                <p class="BookName">Kitabin Bulundugu Sehir: '. $row["City"].'</p>
                                <p class="BookWriter">Kitap Sahibinin Kullanici Adi: '. $row["Username"].' </p>';

                                
                              }
                          ?>



       
        </div>

    
    

        


        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        <script>
            var swiper = new Swiper(".mySwiper", {
              pagination: {
                el: ".swiper-pagination",
                type: "progressbar",
              },
              navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
              },
            });


            function handleButtonClick(buttonType) {
        if (buttonType === 1) {
            // Kullanıcı Girişi butonuna tıklandığında yönlendirme yap
            window.location.href = "KullaniciGirisEkrani.php?newValue=Giris"; // Yönlendirilecek sayfanın URL'sini belirtin
        } else if (buttonType === 2) {
            window.location.href = 'kullaniciGirisEkrani.php?newValue=Kayit';
            
        } else if (buttonType === 3) {
          window.location.href = 'index.php';
            
        } else if (buttonType === 4) {

          <?php 
            echo "window.location.href = 'TakasTalepOlusturma.php?TraderID=" . $KitapSahibiID . "&KitapID=" . $KitapID . "';";
          ?>
            
          }

    }

          </script>

</body>
</html>
