<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alışveriş Kartı</title>
    <link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

      
    <style>


    .p_tag{
        font-size: 30px;  
    }

    </style>  


</head>
<?php
session_start();
    ?>














    <?php


// Oturumda kullanıcı kimliği var mı kontrol et
if (isset($_SESSION['ID'])) {
    // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
    $userId = $_SESSION['ID'];
    
   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      $query = "SELECT Name, Surname FROM kullanicilar WHERE ID = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $userInfo = mysqli_fetch_assoc($result);

        if ($userInfo) {
            
           
        } else {
            echo 'Kullanıcı bilgileri bulunamadı.';
        }
    } else {
        echo 'Sorgu hatası: ' . mysqli_error($conn);
    }
}
?>
<body>
<header>
        <div class="header">
            <div class="logo">
            <a href="index.php">
        <img id="logojpg" src="logo.png" alt="Logo">
    </a>
            </div>
            <div class="quote">
                What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another.
                Mahatma Gandhi
            </div>
            
<script>
    window.onresize = function() {
        var quoteDiv = document.getElementById("quote");
        if (window.innerWidth <= 600) {
            quoteDiv.innerText = "Save Tree";
        } else {
            quoteDiv.innerText = "What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another. Mahatma Gandhi";
        }
    };
</script>
            


            <div class="buttons-container">
                <button id='KullaniciGiris' class="CustomButton" onclick="handleButtonClick(1)">Kullanıcı Girişi</button>
                <button id='KayitOl' class="CustomButton" onclick="handleButtonClick(2)">Kayıt Ol</button>
                <button class="CustomButton" onclick="handleButtonClick(3)">Anasayfa</button>
                <?php
if (isset($_SESSION['ID'])) {

    if ($userInfo) {
        // Kullanıcı adı ve soyadını ekrana yazdır
       
        
        // Butonları tıklanamaz yap ve içlerine isim ve soyisim yaz
        echo '<script>';
        echo 'document.getElementById("KullaniciGiris").innerText = "'.$userInfo['Name'].' '.$userInfo['Surname'].'";';
        echo 'document.getElementById("KullaniciGiris").onclick = function() {
            window.location.href = "KullaniciAnaSayfa.php";
        };;';

        echo 'document.getElementById("KayitOl").innerText = "Cikis";';
        echo 'document.getElementById("KayitOl").onclick = function() {
            window.location.href = "Cikis.php";
        };;';

        echo '</script>';
    } else {
        echo 'Kullanıcı bilgileri bulunamadı.';
    }
}



?>



            </div>
        </div>
        
    </header>
    <div class="container">
<?php
$BookType = trim($_GET['BookType']);

    
$uploadDirectory = 'upload/';
$uploadedImages = scandir($uploadDirectory);



foreach ($uploadedImages as $image) {

    if ($image != '.' && $image != '..') {

        // '{' karakterinin konumunu bul
        $accoladePosition = strpos($image, '{');

        if ($accoladePosition !== false) {
            // '{' karakterinden sonraki kısmı al
            $sonrakiKisim = substr($image, $accoladePosition + 1);

            // '}' karakterinin konumunu bul
            $kapatmaKarakteriPosition = strpos($sonrakiKisim, '}');

            if ($kapatmaKarakteriPosition !== false) {
                // '{' ve '}' arasındaki kısmı al
                $aradakiKisim = substr($sonrakiKisim, 0, $kapatmaKarakteriPosition);

                // '_' karakterine göre ayır
                $parcalanan = explode('_', $aradakiKisim);

                // Değerleri değişkenlere ata
                $resimIndex = $parcalanan[0];
                $BookOwnerID = $parcalanan[1];
                $BookID = $parcalanan[2];
            

               $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                  $query = "SELECT * FROM kitaplar WHERE ID = '$BookID' AND BookType = '$BookType';";
                $result = mysqli_query($conn, $query);

                $row = mysqli_fetch_assoc($result);
                
          
            

                // Değerleri ekrana bastır
               
            } else {
                echo 'Metin içinde "}" karakteri bulunamadı.';
            }
        } else {
            echo 'Metin içinde "{" karakteri bulunamadı.';
        }

        if($resimIndex == 0 and $row){
        echo '    
        <div class="box" onclick=BookPage('.$BookID.')>
            <img src="" alt="">
            <img class="imgdiv" src="' . $uploadDirectory . $image . '" alt="x2"> 
            <p class="p_tag">'.$row['BookName'].'</p>
            <p class="p_tag">'.$row['Writer'].'</p>
        </div>';
    
}
    
    }
}
    










    


?>

</div>

<script>
        function handleButtonClick(buttonType) {
        if (buttonType === 1) {
            // Kullanıcı Girişi butonuna tıklandığında yönlendirme yap
            window.location.href = "KullaniciGirisEkrani.php?newValue=Giris"; // Yönlendirilecek sayfanın URL'sini belirtin
        } else if (buttonType === 2) {
            window.location.href = 'kullaniciGirisEkrani.php?newValue=Kayit';
            
        } else if (buttonType === 3) {
            window.location.href = 'index.php';


            
        }
        KitapSayfa.php
       

    }
    
        function BookPage(BookID) {
            
            window.location.href = 'KitapSayfa.php?BookID='+BookID;

        }
    
    </script>
</body>
</html>
