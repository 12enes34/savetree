<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yatay Bölünmüş HTML</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Brush+Script&display=swap">
    <link rel="stylesheet" href="allCSS.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <script>
    $(document).ready(function(){
        $('#input_4').keyup(function(){
            var username = $(this).val();
            
            $.post('kontrolIsim.php', {'username':username}, function(data){
                $('#usernameMesaj').html(data);
                var yeniDegisken = data;

                var button = document.getElementById("updateButton2");

                if (yeniDegisken == 'Bu kullanıcı adı zaten alınmış.' || yeniDegisken == 'Kullanıcı adı karekteri yetersiz.') {
                    console.log(yeniDegisken);
                    button.setAttribute("disabled", true);
                    $('#usernameMesaj').css("color", "red"); // Uyarı mesajını kırmızı yap
                } else if (yeniDegisken == 'Bu kullanıcı adı kullanılabilir.') {
                    console.log(yeniDegisken);
                    button.removeAttribute("disabled");
                    $('#usernameMesaj').css("color", "black"); // Uyarı mesajını kırmızı yap
                }
            });
        });
    });

    $(document).ready(function(){
        $('#input_3').keyup(function(){
            var mail = $(this).val();
            $.post('kontrolMail.php', {'mail':mail}, function(data){
                $('#mailMesaj').html(data);
                var yeniDegisken = data;

                var button = document.getElementById("updateButton2");

                if (yeniDegisken == 'Bu mail adresi zaten alınmış.' || yeniDegisken == 'Lütfen geçerli bir mail adresi giriniz.') {
                    console.log(yeniDegisken);
                    button.setAttribute("disabled", true);
                    $('#mailMesaj').css("color", "red"); // Uyarı mesajını kırmızı yap
                } else if (yeniDegisken == 'Bu mail adresi kullanılabilir.') {
                    console.log(yeniDegisken);
                    button.removeAttribute("disabled");
                    $('#mailMesaj').css("color", "black"); // Uyarı mesajını kırmızı yap

                }
            });
        });
    });
</script>


<?php
session_start();
$uploadDirectory = 'upload/';
$uploadedImages = scandir($uploadDirectory);

    ?>

<?php


// Oturumda kullanıcı kimliği var mı kontrol et
if (isset($_SESSION['ID'])) {
    // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
    $userId = $_SESSION['ID'];
    
   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      $query = "SELECT * FROM kullanicilar WHERE ID = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $userInfo = mysqli_fetch_assoc($result);

        if ($userInfo) {
            
           
        } else {
            echo 'Kullanıcı bilgileri bulunamadı.';
        }
    } else {
        echo 'Sorgu hatası: ' . mysqli_error($conn);
    }
}
?>


<?php 
    

                // Kullanicinin sahip oldugu kitaplar listesi
                $id = $_SESSION['ID'];

               $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                  $query = "SELECT * FROM kitaplar WHERE BookOwnerID = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $Trade_result = mysqli_stmt_get_result($stmt);

                $listeKullaniciKitaplari = array();//listem

                    if ($Trade_result) {
                        
                        while ($row = mysqli_fetch_assoc($Trade_result)){
                            
                    
                            $listeKullaniciKitaplari[] = $row['ID'];
                        }
                    }
                



                                           

?>








<?php 

$id = $_SESSION['ID']; // kitap sahibinin id si

           $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");              $query = "SELECT * FROM takastalebi WHERE BookGiverID = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);
            $Trade_result = mysqli_stmt_get_result($stmt);

            $listeKullaniciniTakasIstegiGelenKitaplari = array();//listem kulalnincin takas istegi gelen kitaplarinin takas istekleri


                        if ($Trade_result) {
                            
                            while ($row = mysqli_fetch_assoc($Trade_result)){


                              
                                $listeKullaniciniTakasIstegiGelenKitaplari[] = $row['BookID'];


                            }
                        }
                



?>




<?php 

$id = $_SESSION['ID']; // kitap sahibinin id si

$query = "SELECT * FROM takastalebi WHERE BookReceivedID = ?";
                    $stmt = mysqli_prepare($conn, $query);
                    mysqli_stmt_bind_param($stmt, "i", $id);
                    mysqli_stmt_execute($stmt);
                    $Trade_result = mysqli_stmt_get_result($stmt);

                    $listeKullanicininTakasIstegiVerdigiKitaplar = array();//Kullanincinin takas istegi verdigi kitaplarin id leri

                    if ($Trade_result) {
                    

                        while ($row = mysqli_fetch_assoc($Trade_result)){

                            $listeKullanicininTakasIstegiVerdigiKitaplar[] = $row['BookID'];



                        }
                    }




?>




<?php 

$SahipOlunanAdresi = array();
$TakasdakiAdresi = array();
$TakasIstedigiAdresi = array();

$en_uzun_dizi = $listeKullaniciKitaplari;

$uploadDirectory = 'upload/';
$uploadedImages = scandir($uploadDirectory);


if (count($listeKullaniciniTakasIstegiGelenKitaplari) > count($en_uzun_dizi)) {
    $en_uzun_dizi = $listeKullaniciniTakasIstegiGelenKitaplari;
}
if (count($listeKullanicininTakasIstegiVerdigiKitaplar) > count($en_uzun_dizi)) {
    $en_uzun_dizi = $listeKullanicininTakasIstegiVerdigiKitaplar;
}
foreach ($uploadedImages as $image) {

    if ($image != '.' && $image != '..') {

        // '{' karakterinin konumunu bul
        $accoladePosition = strpos($image, '{');

        if ($accoladePosition !== false) {
            // '{' karakterinden sonraki kısmı al
            $sonrakiKisim = substr($image, $accoladePosition + 1);

            // '}' karakterinin konumunu bul
            $kapatmaKarakteriPosition = strpos($sonrakiKisim, '}');

            if ($kapatmaKarakteriPosition !== false) {
                // '{' ve '}' arasındaki kısmı al
                $aradakiKisim = substr($sonrakiKisim, 0, $kapatmaKarakteriPosition);

                // '_' karakterine göre ayır
                $parcalanan = explode('_', $aradakiKisim);

                // Değerleri değişkenlere ata
                $resimIndex = $parcalanan[0];
                $BookOwnerID = $parcalanan[1];
                $BookID = $parcalanan[2];
                
              

                if($resimIndex==0){
                    
               
                    
                    //En uzun dizideki tum elamanlar bitene kadar sirayla hepsini tarar
                    foreach ($en_uzun_dizi as $eleman) {
                      

                        
                        if(in_array($BookID, $listeKullaniciniTakasIstegiGelenKitaplari) && in_array($BookID, $listeKullaniciKitaplari)){
                            $TakasdakiAdresi[] = $uploadDirectory . $image;
                            $SahipOlunanAdresi[] = $uploadDirectory . $image;//kitabin adresi olacak
                            break;
                            
                        }


                        if(in_array($BookID, $listeKullaniciKitaplari)){
                            $SahipOlunanAdresi[] = $uploadDirectory . $image;//kitabin adresi olacak
                         
                            break;
                        }

                        if(in_array($BookID, $listeKullaniciniTakasIstegiGelenKitaplari)){
                            $TakasdakiAdresi[] = $uploadDirectory . $image;
                  
                            break;
                        }




                        if(in_array($BookID, $listeKullanicininTakasIstegiVerdigiKitaplar)){
                            $TakasIstedigiAdresi[] = $uploadDirectory . $image;
             
                            break;
                        }

                     
                        
                    }

                }





                
                
                
                

                // Değerleri ekrana bastır
               
            } else {
                echo 'Metin içinde "}" karakteri bulunamadı.';
            }
        } else {
            echo 'Metin içinde "{" karakteri bulunamadı.';
        }

        // burasi resimIndex == 0 olu
       
    
    }
}




?>
<style>     body {
    margin: 0;
}

.container {
    display: flex;
    height: 80vh;
}

.left-panel {
    flex: 1;
    height: 100%;
    overflow: hidden;
    border: 2px solid rgb(173, 216, 230);
    border-radius: 10px;
    padding: 20px;
    background-color: rgba(173, 216, 230, 0.2);
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

.right-panel {
    flex: 1;
    height: 100%;
    display: flex;
    flex-direction: column;
    border: 2px solid #32CD32;
    border-radius: 10px;
    padding: 20px;
    background-color: rgba(0, 255, 0, 0.05);
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

@media only screen and (max-width: 767px) {
    .container {
        flex-direction: column;
        height: auto;
    }

    .left-panel,
    .right-panel {
        flex: 1;
        height: auto;
        border-radius: 0;
        border: none;
        padding: 10px;
        box-shadow: none;
        background-color: transparent;
    }
}

.top-half {
    flex: 1;
    overflow: hidden;
    border-radius: 10px;
    border: solid rgba(0, 255, 105, 0.2);
}

.bottom-half {
    flex: 1;
    overflow: hidden;
    border-radius: 10px;
    border: solid rgba(0, 255, 105, 0.2);
}

.containerLeft {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.editable-text {
    font-size: 15px;
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px;
    cursor: pointer;
    font-family: 'Brush Script', cursive;
    width: 200px;
    border-radius: 10px;
    text-align: center;
    transition: border-color 0.3s;
    overflow: auto;
}

.editable-text:hover {
    border-color: #66bb6a;
}

.editable-text input {
    font-size: 15px;
    display: none;
    border: 1px solid #ccc;
    padding: 5px;
    font-family: 'Brush Script', cursive;
    width: 100%;
    box-sizing: border-box;
    border-radius: 5px;
    width: calc(100% - 22px);
}

.editable-text span {
    display: inline-block;
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    cursor: pointer;
}

.editable-text input:focus {
    outline: none;
    border-color: #66bb6a;
}

.editable-text.active span {
    display: none;
}

.editable-text.active input {
    display: inline-block;
}

#updateButton,
#updateButton2 {
    margin-top: 20px;
    padding: 10px 20px;
    border: none;
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

#updateButton:hover {
    background-color: #45a049;
}
#updateButton2:hover {
    background-color: #45a049;
}
#AddBookButton {
    margin-top: 20px;
    text-align: center;
    padding: 10px 20px;
    border: none;
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}
/* Küçük ekranlar için buton boyutları ve kitap fotoğrafı boyutu küçültüldü */
@media only screen and (max-width: 767px) {
    #updateButton,
    #updateButton2,
    #AddBookButton{
        margin-top: 10px;
        padding: 8px 16px;
        font-size: 14px;
    }
    #TradeConfirmation{
        margin-top: 10px;
        padding: 8px 16px;
        font-size: 10px;
    }
    .book-image {
        width: 60px;
        height: auto;
        margin-right: 10px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .book-Received,.book-info{
        font-size: 12px;
    }
}

#AddBookButton:hover {
    background-color: #45a049;
}

.books-container,.books-container2 {
    overflow: auto;
    flex-wrap: wrap;
    justify-content: space-between;
    max-height: 300px;
}

.books-container2 {
    max-height: 100px;
}

@media screen and (min-height: 1000px) {
    .books-container {
        max-height: 440px;
    }
}

@media screen and (min-height: 1000px) {
    .books-container2 {
        max-height: 380px;
    }
}




::-webkit-scrollbar {
    display: none;
}

body {
    scrollbar-width: none;
}

.book-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    overflow: auto;
    margin-bottom: 20px;
    padding: 20px;
    border: 2px solid #ccc;
    border-radius: 10px;
    background-color: #f9f9f9;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out;
}

.book-container button {
    background-color: #4CAF50; /* Yeşil */
    color: white;
    border-radius: 5px;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); /* Yatay, dikey, blur, yayılma */
    padding: 5px 10px; /* Yükseklik, Genişlik */
    
    font-size: 14px;
    font-weight: bold;
}

.book-container button:hover {
    background-color: #45a049; /* Koyu Yeşil */
}

.book-container:hover {
    transform: translateY(-5px);
}

.book-info {
    text-align: left;
}

.book-Received {
    text-align: left;
}

.book-image {
    width: 80px;
    height: auto;
    margin-right: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.book-Received button {
    padding: 10px 20px;
    border: none;
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.book-Received button:hover {
    background-color: #45a049;
}

.containerLeft2 {
    flex: 1;
    overflow: auto; /* Bu satırı ekledim */
}


        </style>

</head>
<body>
<header>
        <div class="header">
            <div class="logo">
            <a href="index.php">
        <img id="logojpg" src="logo.png" alt="Logo">
    </a>
            </div>
            <div class="quote" id="quote">
                What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another.
                Mahatma Gandhi
            </div>
            <script>
    window.onresize = function() {
        var quoteDiv = document.getElementById("quote");
        if (window.innerWidth <= 600) {
            quoteDiv.innerText = "Save Tree";
        } else {
            quoteDiv.innerText = "What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another. Mahatma Gandhi";
        }
    };
</script>
            


            <div class="buttons-container">
                <button id='KullaniciGiris' class="CustomButton" onclick="handleButtonClick(1)">Kullanıcı Girişi</button>
                <button id='KayitOl' class="CustomButton" onclick="handleButtonClick(2)">Kayıt Ol</button>
                <button class="CustomButton" onclick="handleButtonClick(3)">Anasayfa</button>
                <?php
if (isset($_SESSION['ID'])) {

    if ($userInfo) {
        // Kullanıcı adı ve soyadını ekrana yazdır
       
        
        // Butonları tıklanamaz yap ve içlerine isim ve soyisim yaz
        echo '<script>';
        echo 'document.getElementById("KullaniciGiris").disabled = true;';
        echo 'document.getElementById("KullaniciGiris").innerText = "'.htmlspecialchars($userInfo['Name'].' '.$userInfo['Surname']).'";';
        
        echo 'document.getElementById("KayitOl").innerText = "Cikis";';
        echo 'document.getElementById("KayitOl").onclick = function() {
            window.location.href = "Cikis.php";
        };;';

        echo '</script>';
    } else {
        echo 'Kullanıcı bilgileri bulunamadı.';
    }
}



?>
            </div>
        </div>
        
    </header>




    <div class="container">
        <div class="left-panel">
            <!-- Sol taraftaki içerik buraya eklenecek -->
            <script>
    function toggleEdit(index) {
      var textElement = document.getElementById('text_' + index);
      var inputElement = document.getElementById('input_' + index);

      textElement.style.display = 'none';
      inputElement.style.display = 'block';
      inputElement.value = textElement.innerText;
      inputElement.focus();
    }

    function updateText(index) {
      var textElement = document.getElementById('text_' + index);
      var inputElement = document.getElementById('input_' + index);

      textElement.innerText = inputElement.value;
      textElement.style.display = 'block';
      inputElement.style.display = 'none';
    }
    function TradeCancelOwnerClick(idBook){
                window.location.href = 'TradeCancelOwner.php?idBook='+idBook;
            }

            function TradeCancelClick(tradeID){
                window.location.href = 'TradeCancelReceived.php?tradeID='+tradeID;
            }
            function AddBook(){
                window.location.href = 'AddBook.php?';

            }
  </script>
</head>
<body>
  <div class="containerLeft">
    <div class="editable-text" onclick="toggleEdit(1)">Name:
    
    <?php
echo '
    
      <span id="text_1">'.htmlspecialchars((!empty($userInfo['Name'])) ? $userInfo['Name'] : '').'</span>
      <input id="input_1" type="text" onblur="updateText(1)">
    </div>
    <div class="editable-text" onclick="toggleEdit(2)">Surname:
      <span id="text_2">'.htmlspecialchars((!empty($userInfo['Surname'])) ? $userInfo['Surname'] : '').'</span>
      <input id="input_2" type="text" onblur="updateText(2)">
    </div>
    <div class="editable-text" onclick="toggleEdit(3)">Mail:
    <span id="mailMesaj"></span><br> <!-- Bu span, kullanıcı adı kontrol mesajlarını gösterecek -->

      <span id="text_3">'.htmlspecialchars((!empty($userInfo['Mail'])) ? $userInfo['Mail'] : '').'</span>
      <input id="input_3" type="text" onblur="updateText(3)">
    </div>
    
    <div class="editable-text" id="username" onclick="toggleEdit(4)">Username:
    <span id="usernameMesaj"></span><br> <!-- Bu span, kullanıcı adı kontrol mesajlarını gösterecek -->

      <span id="text_4">'.htmlspecialchars((!empty($userInfo['Username'])) ? $userInfo['Username'] : '').'</span>
      <input id="input_4" type="text" onblur="updateText(4)">
      
    </div>
    <div class="editable-text" onclick="toggleEdit(5)">PhoneNumber:
      <span id="text_5">'.htmlspecialchars((!empty($userInfo['PhoneNumber'])) ? $userInfo['PhoneNumber'] : '').'</span>
      <input id="input_5" type="text" onblur="updateText(5)">
    </div>
    <div class="editable-text" onclick="toggleEdit(6)">City:
      <span id="text_6">'.htmlspecialchars((!empty($userInfo['City'])) ? $userInfo['City'] : '').'</span>
      <input id="input_6" type="text" onblur="updateText(6)">
    </div>
';
?>
<div>
    <button id="updateButton2" onclick="handleButtonClick(5)">Güncelle</button>
    <button id="updateButton" onclick="handleButtonClick(4)">Şifre sıfırla</button>
    <button id="AddBookButton" onclick="AddBook()">Kitap Ekle</button>
    </div>
  </div>
  <div class="containerLeft2">
    KİTAPLARINIZ     

  <div class="books-container2">


  <script>
        function BookErase(BookID){
                window.location.href = 'BookErase.php?BookID='+BookID;
            }
  </script>
    <?php
            if (isset($_SESSION['ID'])) {
                // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
                $id = $_SESSION['ID'];//Kitap sahibinin idsi

               $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                  $query = "SELECT * FROM kullanicilar WHERE ID = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);







                if ($result) {
                $row = mysqli_fetch_assoc($result);
                $BookOwnerUsername = $row["Username"];
                $BookOwnerName = $row["Name"];
                

                }


               $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      
                $query = "SELECT * FROM kitaplar WHERE BookOwnerID = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $Trade_result = mysqli_stmt_get_result($stmt);
                
                $fotoid=0;

                            if ($Trade_result) {
                                while ($row = mysqli_fetch_assoc($Trade_result)){
                                    $imageDirectory = $SahipOlunanAdresi[$fotoid];

                                    $ID = $row['ID'];
                                    $Writer = $row['Writer'];
                                    $PublicationYear = $row['PublicationYear'];
                                    $PublicationNumber = $row['PublicationNumber'];
                                    $BookName = $row['BookName'];
                                    $BookType = $row['BookType'];
                                    $idBook = $row['ID'];


                                    echo '<div class="book-container">
                                    <img  onclick=BookPage('.$idBook.') src="' .  $imageDirectory . '" alt="Book 7" class="book-image">
                                    <div class="book-info">
                                        <h3>Kitap adi :'.$BookName.'</h3>
                                        <p>Yazari :'.$Writer.'</p>
                                    </div>
                                    <div class="book-Received">
                                    
                                        <h3>Kitap sahibi adi: '.$BookOwnerName.'</h3>
                                        <p>Kitap sahibi soyadi: '.$BookOwnerUsername.'</p>
                                        <button id="TradeConfirmation" onclick="BookErase('.$idBook.')">KITAP SIL</button>
                                    </div>
                                    
                                </div>';
                                $fotoid +=1;
                                
                                

            }}}

    ?>
</div>
                            










                



  </div>
        </div>
        <div class="right-panel">
            <div class="top-half">
                <!-- Sağ üst taraftaki içerik buraya eklenecek -->
                KİTAPLARINIZA GELEN TAKAS İSTEKLERİ

                <div class="books-container">
                <?php
          if (isset($_SESSION['ID'])) {
            // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
            $id = $_SESSION['ID'];//Kitap sahibinin idsi
            $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");              $id = $_SESSION['ID'];
            $query = "SELECT * FROM takastalebi WHERE BookGiverID = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);
            $Trade_result = mysqli_stmt_get_result($stmt);

            $fotoid=0;

                        if ($Trade_result) {
                            while ($row = mysqli_fetch_assoc($Trade_result)){
                                $imageDirectory = $TakasdakiAdresi[$fotoid];

                                $idBook = $row['BookID'];
                                $bookReciverID = $row['BookReceivedID'];
                                $tradeID = $row['ID'];
                                $TradeConfirmation = $row['Confirmation'];


                                $conn2 = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");
                                $query2 = "SELECT * FROM kitaplar WHERE ID = ?";
                                $stmt2 = mysqli_prepare($conn2, $query2);
                                mysqli_stmt_bind_param($stmt2, "i", $idBook);
                                mysqli_stmt_execute($stmt2);
                                $result2 = mysqli_stmt_get_result($stmt2);
                                $row2 = mysqli_fetch_assoc($result2);
                                

                                $conn3 = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");
                                $query3 = "SELECT * FROM kullanicilar WHERE ID = ?";
                                $stmt3 = mysqli_prepare($conn3, $query3);
                                mysqli_stmt_bind_param($stmt3, "i", $bookReciverID);
                                mysqli_stmt_execute($stmt3);
                                $result3 = mysqli_stmt_get_result($stmt3);

                               
                                $row3 = mysqli_fetch_assoc($result3);


                             



                                

                                    if($TradeConfirmation){
    
                                        echo '
                                    <div class="book-container">
                                    <img onclick=BookPage('.$BookID.') src=' . $imageDirectory . ' alt="Book 7" class="book-image">
                                    <div class="book-info">
                                        <h3>Kitap adi :'.$row2['BookName'].'</h3>
                                        <p>Yazari :'.$row2['Writer'].'</p>
                                    </div>
                                    <div class="book-Received">
                                    
                                        <h3>Takas isteyenin adi: '.$row3['Name'].'</h3>
                                        <p>Takas isteyenin soyadi: '.$row3['Surname'].'</p>
                                        <button id="TradeConfirmation" onclick="TradeCancelOwnerClick('.$idBook.')">Takas iptal</button>
                                    </div>
                                    <div>
                                    <button id="TradeConfirmation" onclick="TradeConfirmationClick('.$tradeID.',0)">Onayi geri al</button>
                                    
                                    </div>
                                </div>';
    
                                    }
                                    else{
    
                                    echo '
                                    <div class="book-container">
                                    <img onclick=BookPage('.$BookID.') src="' . $imageDirectory . '" alt="Book 7" class="book-image">
                                    <div class="book-info">
                                        <h3>Kitap adi: '.$row2['BookName'].'</h3>
                                        <p>Yazari: '.$row2['Writer'].'</p>
                                    </div>
                                    <div class="book-Received">
                                    
                                        <h3>Takas isteyenin adi: '.$row3['Name'].'</h3>
                                        <p>Takas isteyenin soyadi: '.$row3['Surname'].'</p>
                                        <button id="TradeConfirmation" onclick="TradeCancelOwnerClick('.$idBook.')">Takas iptal</button>
                                    </div>
                                    <div>
                                    <button id="TradeConfirmation" onclick="TradeConfirmationClick('.$tradeID.',1)">Takasi Onayla</button>
                                    
                                    </div>
                                </div>';
                                    }
                                    $fotoid +=1;
                               
            } 
    
        } else {
            echo 'Sorgu hatası: ' . mysqli_error($conn);
        }
    }





          ?>




    
    </div>
            </div>
            <div class="bottom-half">
                <!-- Sağ alt taraftaki içerik buraya eklenecek -->
                TAKAS İSTEĞİ VERDİĞİNİZ KİTAPLAR
                <div class="books-container">
                    



                    <?php
                    $fotoid=0;

                    $id = $_SESSION['ID'];//Kitap sahibinin idsi
                   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                      $id = $_SESSION['ID'];
                    $query = "SELECT * FROM takastalebi WHERE BookReceivedID = ?";
                    $stmt = mysqli_prepare($conn, $query);
                    mysqli_stmt_bind_param($stmt, "i", $id);
                    mysqli_stmt_execute($stmt);
                    $Trade_result = mysqli_stmt_get_result($stmt);

                    if ($Trade_result) {
                        while ($row = mysqli_fetch_assoc($Trade_result)){

                                $imageDirectory = $TakasIstedigiAdresi[$fotoid];


                                $BookGiverID = $row['BookGiverID'];
                                $idBook = $row['BookID'];
                                $bookReciverID = $row['BookReceivedID'];
                                $tradeID = $row['ID'];
                                $TradeConfirmation = $row['Confirmation'];

                                $conn2 = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                                  $query2 = "SELECT * FROM kitaplar WHERE ID = ?";
                                $stmt2 = mysqli_prepare($conn2, $query2);
                                mysqli_stmt_bind_param($stmt2, "i", $idBook);
                                mysqli_stmt_execute($stmt2);
                                $result2 = mysqli_stmt_get_result($stmt2);
                                $row2 = mysqli_fetch_assoc($result2);
                                

                                $conn3 = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                                  $query3 = "SELECT * FROM kullanicilar WHERE ID = ?";
                                $stmt3 = mysqli_prepare($conn3, $query3);
                                mysqli_stmt_bind_param($stmt3, "i", $BookGiverID);
                                mysqli_stmt_execute($stmt3);
                                $result3 = mysqli_stmt_get_result($stmt3);
                                $row3 = mysqli_fetch_assoc($result3);






                                




                                    echo'   <div  class="book-container">
                                    <img onclick=BookPage('.$BookID.') src="' . $imageDirectory . '" alt="Book 7" class="book-image">
                                                <div class="book-info">
                                                    <h3>Kitap adi: '.$row2['BookName'].'</h3>
                                                    <p>Yazari: '.$row2['Writer'].'</p>
                                                </div>
                                                <div class="book-Received">
                                                
                                                    <h3>Kitap sahibi adi: '.$row3['Name'].'</h3>
                                                    <p>Kitap sahibi soyadi: '.$row3['Surname'].'</p>
                                                    <button id="TradeConfirmation" onclick="TradeCancelClick('.$tradeID.')">Takas iptal</button>
                                                    
                                                </div>
                                                <div>';
                                                if($row['Confirmation']){
                                                    $BookGiverID = $row['BookGiverID'];
                                                    $id = $_SESSION['ID'];//Kitap sahibinin idsi
                                                    
                                                    $conn2 = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                                                      
                                                    
                                                    $query2 = "SELECT * FROM kullanicilar WHERE ID = ?";
                                                    $stmt2 = mysqli_prepare($conn2, $query2);
                                                    mysqli_stmt_bind_param($stmt2, "i", $BookGiverID);
                                                    mysqli_stmt_execute($stmt2);
                                                    $GiverInfo = mysqli_stmt_get_result($stmt2);
                                                    $row = mysqli_fetch_assoc($GiverInfo);
                
                
                
                                                echo '<button id="TradeConfirmation"  disabled> onaylandi '.$row['PhoneNumber'].'</button>
                                                
                                                </div>
                                            </div>';}
                                            else{
                                                echo '<button id="TradeConfirmation" disabled >Onaylanmadi</button>
                                                
                                                </div>
                                            </div>';}
                                            $fotoid +=1;





                                                           
}}
                            ?>
                </div>
            
            </div>
        </div>
    </div>








    
    

        


        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        <script>
  
            function TradeConfirmationClick(tradeID,TradeResult) {
                
                window.location.href = 'TradeConfirmation.php?tradeID='+tradeID+'&TradeResult='+TradeResult;
            
            
            }


            function handleButtonClick(buttonType) {
        if (buttonType === 1) {
            
            window.location.href = "KullaniciGirisEkrani.php?newValue=Giris"; // Yönlendirilecek sayfanın URL'sini belirtin
        } else if (buttonType === 2) {
            window.location.href = 'kullaniciGirisEkrani.php?newValue=Kayit';
            
        } else if (buttonType === 3) {
            window.location.href = 'index.php';

            
        } else if (buttonType === 4) {
            window.location.href = 'SifreSifirlama.php';
            
        } else if (buttonType === 5) {
            var textValues = [];

            for (var i = 1; i <= 6; i++) {
            var textElement = document.getElementById('text_' + i);
            textValues.push(textElement.innerText);
            }

        window.location.href = 'update.php?Name='+textValues[0]+'&Surname='+textValues[1]+'&Mail='+textValues[2]+'&Username='+textValues[3]+'&PhoneNumber='+textValues[4]+'&City='+textValues[5];
        } 

        function TradeCancelClick(tradeID){
                window.location.href = 'TradeCancelReceived.php?tradeID='+tradeID;
            }

    }
    function BookPage(BookID) {
            
            window.location.href = 'KitapSayfa.php?BookID='+BookID;

        }
          </script>

</body>
</html>
