<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
           body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            
        }
       
        .success-message {
            color: #155724;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .error-message {
            color: #721c24;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
    </style>
</head>
<body>

<?php
// PHP oturum süresi ayarı
ini_set('session.cookie_lifetime', 3600); // Örnek: 1 saat
ini_set('session.gc_maxlifetime', 3600); // Örnek: 1 saat

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Kullanıcı adı ve parolayı alın
    $username = trim($_POST["usernameLog"]);
    $passwordToCheck = trim($_POST["passwordLog"]); // Girilen parolayı doğrudan alın

    // Kullanıcıyı veritabanından bulun (örneğin)
   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  
    $query = "SELECT Password, ID FROM kullanicilar WHERE Username = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username); // "s" string tipi olduğunu belirtir
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        // Kullanıcı varsa bir satır alın
        $row = mysqli_fetch_assoc($result);

        if ($row) {
            

            // Parolayı kontrol et ve eğer başarılıysa oturumu açık bırak
            if (password_verify($passwordToCheck, $row["Password"])) {
                // Giriş başarılı, oturumu açık bırak
                $_SESSION['ID'] = $row['ID']; // Örnek olarak kullanıcı kimliğini sakladım
                echo 'im doing evreytingh right';

                // Oturumu yaz ve kapat
                session_write_close();

                // 2 saniye sonra başka bir sayfaya yönlendir
                header("Location: index.php");
                exit; // Header'dan sonra ek kodların çalışmasını engeller
            } else {
                echo '<div class="error-message">Yanlış parola!</div>';
                sleep(2);
                //header("Location: KullaniciGirisEkrani.php");
            }
        } else {
           
            echo '<div class="error-message">Kullanıcı bulunamadı!</div>';
            sleep(2);
            //header("Location: KullaniciGirisEkrani.php");
        }
    } else {
        echo '<div class="error-message">Sorgu hatası: ' . mysqli_error($conn) . '</div>';
    }
}
?>
    
    </body>
</html>