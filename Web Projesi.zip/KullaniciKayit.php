<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .success-message {
        color: #155724;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        padding: 10px;
        border-radius: 5px;
    }

    .error-message {
        color: #721c24;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        padding: 10px;
        border-radius: 5px;
    }
    </style>
</head>
<body>

<?php
session_start(); // Oturumu başlat
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


if (!empty($_GET['token'])) {
    $tokenControl = htmlspecialchars(trim($_GET['token']));
    echo '9 work';


    if (isset($_SESSION['token'])) {
        
        $token = $_SESSION['token']; // Token değerini al
        if($token == $tokenControl){
        echo "Token: " . $token;






// $token değişkeni şimdi güvenli bir şekilde alınmış veya varsayılan değere sahip.





           $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");         
            // Formdan gelen verileri al



            $username = mysqli_real_escape_string($conn, $_SESSION['user_data']['username']);
            $mail = mysqli_real_escape_string($conn, $_SESSION['user_data']['mail']);
            $password = mysqli_real_escape_string($conn, $_SESSION['user_data']['password']);
            $name = mysqli_real_escape_string($conn, $_SESSION['user_data']['name']);
            $surname = mysqli_real_escape_string($conn, $_SESSION['user_data']['surname']);
            $number = mysqli_real_escape_string($conn, $_SESSION['user_data']['number']);
            $city = mysqli_real_escape_string($conn, $_SESSION['user_data']['city']);
            
            // $username = 'afghjvcasdasdv';
            // $mail = 'enes12_34@hotmail.com';
            // $password = 'a';
            // $name = 'a';
            // $surname = 'a';
            // $number = '901111';
            // $city ='a';

            // SQL sorgusu oluştur
$query = "INSERT INTO kullanicilar (Username, Mail, Password, Name, Surname, PhoneNumber, City) 
VALUES (?, ?, ?, ?, ?, ?, ?)";

// Hazırlıklı ifadeyi hazırla
$stmt = mysqli_prepare($conn, $query);

// Bağlantı ve sorgu başarılıysa devam et
if ($stmt) {
// Parametreleri bağla
mysqli_stmt_bind_param($stmt, "sssssss", $username, $mail, $password, $name, $surname, $number, $city);

// Sorguyu çalıştır
mysqli_stmt_execute($stmt);

// İşlem başarılıysa mesajı göster
if (mysqli_stmt_affected_rows($stmt) > 0) {
echo "Kullanıcı başarıyla kaydedildi.";
} else {
echo "Kullanıcı kaydedilirken bir hata oluştu.";
}

// İfadenin bağlantısını kapat
mysqli_stmt_close($stmt);
} else {
echo "Hazırlıklı ifade hazırlanırken bir hata oluştu.";
}
echo '<div class="success-message">';
echo 'Doğrulama işlemi başarili';
echo '</div>';





sleep(2);
$_SESSION = array();

header("Location: kullaniciGirisEkrani.php");


 

}else {
    echo "Token eslesmiyor.";
}


} else {
    echo "Token bulunamadı.";
}







} else {
    // $_GET['token'] dolu değilse veya boş ise, varsayılan bir değer atayabiliriz.
   



require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

// Şifre sıfırlama bağlantısı oluştur
$token = bin2hex(random_bytes(32));



$mail = new PHPMailer(true);
try {
 //Server settings
 $mail->SMTPDebug = 0; // debug on - off 2 yada 3 ile detayli bilgi doner
 $mail->isSMTP(); 
 $mail->Host = 'smtp-mail.outlook.com'; // SMTP sunucusu örnek : mail.alanadi.com
 $mail->SMTPAuth = true; // SMTP Doğrulama
 $mail->AuthType = 'CRAM-MD5';
 $mail->Username = 'whaf5@hotmail.com'; // Mail kullanıcı adı
 $mail->Password = 'xenesx1234'; // Mail şifresi
 $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
 $mail->Port = 587; // SMTP Port
 $mail ->Timeout = 300; // ne kadar süre denensin gönderme işlemi?  
 $mail->SMTPOptions = array(
 'ssl' => array(
 'verify_peer' => false,
 'verify_peer_name' => false,
 'allow_self_signed' => true
 )
);
$UserMail = $_POST['mail'];

$conn = mysqli_connect('localhost', 'root', '', 'savetree_kitaptakasi');

$_SESSION['user_data'] = array(
    'username' => mysqli_real_escape_string($conn, $_POST['username']),
    'mail' => mysqli_real_escape_string($conn, $_POST['mail']),
    'password' => password_hash($_POST["password"], PASSWORD_DEFAULT),
    'name' => mysqli_real_escape_string($conn, $_POST['name']),
    'surname' => mysqli_real_escape_string($conn, $_POST['surname']),
    'number' => mysqli_real_escape_string($conn, $_POST['number']),
    'city' => mysqli_real_escape_string($conn, $_POST['city'])
);




// Başka bir değişkeni oturum değişkenine atama
$_SESSION['token'] = $token;

        // <?php echo htmlspecialchars($_GET['token']); 

        $sozlesmeMetni = "
        1. Taraflar<br>
        Bu sözleşme, savetree olarak bilinen web sitesi aracılığıyla sunulan hizmetlerin kullanımı için Kullanıcı arasında yapılır.<br><br>
        2. Hizmetler<br>
        savetree, kullanıcılara kitap takası yapma imkanı sağlar. Kullanıcılar, savetree üzerinden kayıt olarak kendi kitaplarını listeleme ve diğer kullanıcıların kitaplarını gözden geçirme hakkına sahiptir.<br><br>
        3. Kayıt Bilgileri<br>
        Kullanıcılar, savetree'ye kayıt olurken gerçek ve doğru bilgileri sağlamakla yükümlüdürler. Bu bilgiler arasında ad, soyad, e-posta, telefon numarası, bulundukları şehir gibi bilgiler bulunur.<br><br>
        4. Kitap Ekleme<br>
        Kullanıcılar, savetree üzerinden takas için kitap eklerken, her kitabın minimum 1 adet ve maksimum 4 adet fotoğrafını yüklemek zorundadır. Kitap bilgileri arasında kitabın adı, yazarı, basım numarası, yayın numarası, kitap türü gibi bilgiler yer almalıdır.<br><br>
        5. Takas İşlemleri<br>
        Kullanıcılar, savetree üzerinden diğer kullanıcıların kitaplarını gözden geçirebilir ve beğendiği kitaplara takas teklifi gönderebilirler. Takas teklifi kabul edilirse, kitap sahibi ile takas detayları paylaşılır.<br><br>
        6. Gizlilik ve Güvenlik<br>
        Kullanıcılar, savetree üzerinde paylaştıkları bilgilerin gizliliğinin korunmasından sorumludur. savetree, kullanıcıların kişisel verilerini güvenli bir şekilde saklar ve üçüncü şahıslarla paylaşmaz.<br><br>
        7. Sorumluluklar ve Taahhütler<br>
        Kullanıcılar, savetree'yi yasalara uygun şekilde kullanmakla yükümlüdürler. Kullanıcılar, savetree üzerinden yaptıkları işlemlerden tamamen sorumludur ve savetree'nin herhangi bir zarardan sorumlu olmadığını kabul ederler.<br><br>
        8. Değişiklikler ve İptal<br>
        savetree, bu kullanıcı sözleşmesini herhangi bir zamanda değiştirme hakkını saklı tutar. Kullanıcılar, sözleşme değişikliklerini kabul etmezlerse, savetree'yi kullanmayı iptal etme hakkına sahiptirler.<br><br>
        Bu sözleşmeyi ve maili onaylamak ve savetree'yi kullanmaya başlamak, bu şartları kabul ettiğiniz anlamına gelir.
        ";


        $mesaj = "Merhaba,<br><br>";
        $mesaj .= "Sözleşmemizi onaylamak için aşağıdaki bağlantıya tıklayın:<br>";
        $mesaj .= "<a href='http://localhost/Web%20Projesi/KullaniciKayit.php?token=" . $token . "'>Onay Bağlantısı</a><br><br>";

        $mesaj .= "Bu sözleşmeyi ve maili onaylamak ve savetree'yi kullanmaya başlamak, bu şartları kabul ettiğiniz anlamına gelir.<br><br>";
        $mesaj .= "İyi günler dileriz.<br><br>";
        $mesaj .= "Sözleşme Metni:<br><br>";
        $mesaj .= $sozlesmeMetni;


        











$ekAyarlar = array(
    'charset' => 'UTF-8',
    'Content-Type' => 'text/html'
);
//Alıcılar
 $mail->setfrom('whaf5@hotmail.com', 'Sözleşme Onayı'); //mail gonderen mail adresi
 $mail->addAddress($_POST['mail']);//hedef mail adresi
 $mail->addReplyTo($_POST['mail'],'SAVE TREE');//SAVE TREE yazan yer geri donusleri alabilecegin bir mail adresi olmali
 //İçerik
 $mail->isHTML(true);
 $mail->Subject = 'Save Tree ye hoşgeldiniz';
 $mail->Body = $mesaj;

 
 $mail->ContentType = $ekAyarlar['Content-Type'];
 $mail->CharSet = $ekAyarlar['charset'];


 $mail->send();
  // Mesaj gönderme işlemi başarılıysa
  echo '<div class="success-message">';
  echo 'Doğrulama mesajınız başarıyla iletilmiştir: ' . htmlspecialchars($_POST['mail']);
  echo '</div>';
} catch (Exception $e) {
// Mesaj gönderme işlemi başarısızsa
echo '<div class="error-message">';
echo 'Doğrulama mesajınız iletilirken bir hata oluştu: ' . $mail->ErrorInfo;
echo '</div>';}
}
// sifremi unuttuma basinca once mail adresini girmen isteniyor, gonderildigine dair mesaj yazan bir ekran , Mail geliyor sifreyi sifirlamk icin tiklayin diye , tiklayinca yeni parola girme ekranina atiyor
?>
    
    </body>
</html>