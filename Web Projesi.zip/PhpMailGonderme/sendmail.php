<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';


$mail = new PHPMailer(true);
try {
 //Server settings
 $mail->CharSet = 'UTF-8';
 $mail->SMTPDebug = 3; // debug on - off
 $mail->isSMTP(); 
 $mail->Host = 'smtp-mail.outlook.com'; // SMTP sunucusu örnek : mail.alanadi.com
 $mail->SMTPAuth = true; // SMTP Doğrulama
 $mail->AuthType = 'CRAM-MD5';
 $mail->Username = 'whaf5@hotmail.com'; // Mail kullanıcı adı
 $mail->Password = 'xenesx1234'; // Mail şifresi
 $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
 $mail->Port = 587; // SMTP Port
 $mail ->Timeout = 300; // ne kadar süre denensin gönderme işlemi?  
 $mail->SMTPOptions = array(
 'ssl' => array(
 'verify_peer' => false,
 'verify_peer_name' => false,
 'allow_self_signed' => true
 )
);

 //Alıcılar
 $mail->setfrom('whaf5@hotmail.com', 'İletişim Formu');
 $mail->addAddress($_POST['mail']);//hedef mail adresi
 $mail->addReplyTo($_POST['mail'], $_POST['name']);
 //İçerik
 $mail->isHTML(true);
 $mail->Subject = 'İletişim Formu.';
 $mail->Body = $_POST['message'];

 $mail->send();
 echo "Mesajınız İletildi --> ".$_POST['mail']."<br>";
} catch (Exception $e) {
 echo 'Mesajınız İletilemedi. Hata: ', $mail->ErrorInfo;
}

?>