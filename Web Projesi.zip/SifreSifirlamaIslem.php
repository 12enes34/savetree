<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    .success-message {
        color: #155724;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        padding: 10px;
        border-radius: 5px;
    }

    .error-message {
        color: #721c24;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        padding: 10px;
        border-radius: 5px;
    }
</style>

</head>
<body>
    


<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

// Şifre sıfırlama bağlantısı oluştur
$token = bin2hex(random_bytes(32));

$_SESSION['token'] = $token;


$mail = new PHPMailer(true);
try {
 //Server settings
 $mail->CharSet = 'UTF-8';
 $mail->SMTPDebug = 0; // debug on - off 2 yada 3 ile detayli bilgi doner
 $mail->isSMTP(); 
 $mail->Host = 'smtp-mail.outlook.com'; // SMTP sunucusu örnek : mail.alanadi.com
 $mail->SMTPAuth = true; // SMTP Doğrulama
 $mail->AuthType = 'CRAM-MD5';
 $mail->Username = 'whaf5@hotmail.com'; // Mail kullanıcı adı
 $mail->Password = 'xenesx1234'; // Mail şifresi
 $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
 $mail->Port = 587; // SMTP Port
 $mail ->Timeout = 300; // ne kadar süre denensin gönderme işlemi?  
 $mail->SMTPOptions = array(
 'ssl' => array(
 'verify_peer' => false,
 'verify_peer_name' => false,
 'allow_self_signed' => true
 )
);

    $UserMail = trim($_POST['email']);

   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      

    $query = "SELECT * FROM kullanicilar WHERE Mail = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $UserMail);//"s" string , "i": Tam sayı (integer) , "d": Ondalık sayı (double) , "b": Blob (binary large object)
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);


        if ($row = mysqli_fetch_assoc($result)) {
            $id = $row['ID']; // Kullanıcı ID'sini al
        } else {
            // Kullanıcı bulunamadıysa hata mesajı göster ve işlemi sonlandır
            
            echo '<div class="error-message">';
            echo 'Kullanıcı bulunamadı.';
            echo '</div>';

            exit;
        }






$mesaj = " Merhaba, Kullanici adiniz: ".$row['Username']. " şifrenizi sıfırlamak için aşağıdaki bağlantıya tıklayın:\n\n";
$mesaj .= '<a href="http://localhost/Web%20Projesi/SifreSifirlamaMail.php?token=' . $token . '&mail=' . $UserMail . '&name=' . $row['Name'] . '&surname=' . $row['Surname'] . '&username=' . $row['Username'] . '&phonenumber=' . $row['PhoneNumber'] . '">Şifre sıfırlama linki</a>';
//Alıcılar
 $mail->setfrom('whaf5@hotmail.com', 'İletişim Formu'); //mail gonderen mail adresi
 $mail->addAddress(trim($_POST['email']));//hedef mail adresi
 $mail->addReplyTo(trim($_POST['email']),'test name kismi'); //test name kismini degistir
 //İçerik
 $mail->isHTML(true);
 $mail->Subject = 'Save Tree Şifre Sıfırlama';
 $mail->Body = $mesaj;

 $mail->send();
  // Mesaj gönderme işlemi başarılıysa
  echo '<div class="success-message">';
  echo 'Mesajınız başarıyla iletilmiştir: ' . htmlspecialchars(trim($_POST['email']));
  echo '</div>';
} catch (Exception $e) {
// Mesaj gönderme işlemi başarısızsa
echo '<div class="error-message">';
echo 'Mesajınız iletilirken bir hata oluştu: ' . $mail->ErrorInfo;
echo '</div>';}

// sifremi unuttuma basinca once mail adresini girmen isteniyor, gonderildigine dair mesaj yazan bir ekran , Mail geliyor sifreyi sifirlamk icin tiklayin diye , tiklayinca yeni parola girme ekranina atiyor
?>


</body>
</html>