<!DOCTYPE html>
<html>
<head>
    <title>Şifre Sıfırlama</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-top: 0;
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="password"] {
            width: calc(100% - 32px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            float: left;
        }
        input[type="text"] {
            width: calc(100% - 32px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            float: left;
        }
        .toggle-password {
            background-color: transparent;
            border: none;
            padding: 0;
            float: right;
            cursor: pointer;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .error-message {
    color: red;
    font-weight: bold;
    font-size: 16px;
    padding: 10px;
    border: 2px solid red;
    border-radius: 5px;
    background-color: #ffe6e6;
}

    </style>
</head>
<body>
<?php
        session_start();
//sikinti olursa trim() fonksiyonunu kaldir
if (!empty($_GET['token'])) {
   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      $tokenControl = htmlspecialchars(trim($_GET['token']));
    $Usermail = mysqli_real_escape_string($conn, trim($_GET['mail']));
    $UserName = mysqli_real_escape_string($conn, trim($_GET['name']));
    $UserSurname = mysqli_real_escape_string($conn, trim($_GET['surname']));
    $UserUsername = mysqli_real_escape_string($conn, trim($_GET['username']));
    $PhoneNumber = mysqli_real_escape_string($conn, trim($_GET['phonenumber']));
   
    


    if (isset($_SESSION['token'])) {
        
        $token = $_SESSION['token']; // Token değerini al
        if($token == $tokenControl){
            echo "
            <div class=\"container\">
                <h2>Yeni Şifre Oluştur</h2>
                <form action=\"SifreSifirlamaMailislemi.php\" method=\"post\">
    <input type=\"hidden\" name=\"token\" value=\"$tokenControl\">
    <input type=\"hidden\" name=\"mail\" value=\" $Usermail\">
    <input type=\"hidden\" name=\"name\" value=\" $UserName\">
    <input type=\"hidden\" name=\"surname\" value=\" $UserSurname\">
    <input type=\"hidden\" name=\"username\" value=\"$UserUsername\">
    <input type=\"hidden\" name=\"phonenumber\" value=\" $PhoneNumber\">

    <label for=\"new_password\">Yeni Şifre:</label>
    <input type=\"password\" id=\"new_password\" name=\"new_password\">
    <button type=\"button\" class=\"toggle-password\" onclick=\"togglePasswordVisibility('new_password')\">Göster/Gizle</button>

    <label for=\"confirm_password\">Yeni Şifreyi Tekrar Girin:</label>
    <input type=\"password\" id=\"confirm_password\" name=\"confirm_password\">
    <button type=\"button\" class=\"toggle-password\" onclick=\"togglePasswordVisibility('confirm_password')\">Göster/Gizle</button>

    <input type=\"submit\" value=\"Şifreyi Güncelle\">
</form>

            </div>
            
            <script>
                function togglePasswordVisibility(inputId) {
                    var input = document.getElementById(inputId);
                    if (input.type === 'password') {
                        input.type = 'text';
                    } else {
                        input.type = 'password';
                    }
                }
            </script>";

            //header("Location: SifreSifirlamaSonuc.php?token=$token&mail=$Usermail&name=$UserName&surname=$UserSurname&username=$UserUsername&phonenumber=$PhoneNumber");
            exit();
            
} else{
    echo '<div class="error-message" style="color: red; font-weight: bold;">Hatalı token!</div>';
  
}

}
}

?>
</body>
</html>
