<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifre Sıfırlama Başarılı</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            color: #333;
        }
        p {
            color: #4CAF50;
            font-size: 18px;
        }
        a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Şifre Sıfırlama Başarılı</h2>
        <p>Şifreniz başarıyla sıfırlandı.</p>
        <p><a href="index.php">Giriş yapmak için buraya tıklayın</a></p>
    </div>



<?php
session_start();
$conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $token = trim($_POST['token']);

    $Usermail = mysqli_real_escape_string($conn, trim($_POST['mail']));
    $UserName = mysqli_real_escape_string($conn, trim($_POST['name']));
    $UserSurname = mysqli_real_escape_string($conn, trim($_POST['surname']));
    $UserUsername = mysqli_real_escape_string($conn, trim($_POST['username']));
    $PhoneNumber = mysqli_real_escape_string($conn, trim($_POST['phonenumber']));

    $newPassword = mysqli_real_escape_string($conn, trim($_POST['new_password']));
    
    $confirmPassword = trim($_POST['confirm_password']);

    // Token ve şifreleri doğrulama işlemleri burada gerçekleştirilir

    if ($newPassword === $confirmPassword) {


        // Yeni şifre veritabanında güncellenir
        // updatePassword($token, $newPassword); // Veritabanınıza uygun şekilde güncelleme işlemini gerçekleştirin
        
        $newPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $query = "UPDATE kullanicilar SET Password = ? WHERE mail = ? AND Name = ? AND Surname = ? AND Username = ? AND PhoneNumber = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "ssssss", $newPassword, $Usermail, $UserName, $UserSurname, $UserUsername, $PhoneNumber);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_execute($stmt)) {
            
        } else {
            echo "Sorgu çalıştırılırken bir hata oluştu: " . mysqli_stmt_error($stmt);
        }
        }
        
        session_unset(); // Tüm oturum değişkenlerini temizle
        session_destroy(); // Oturumu sonlandır
        //echo 'work 82' , $newPassword;
        // Ana sayfaya yönlendir
        //header("Location: index.php");
        exit();
    }
?>

</body>
</html>
