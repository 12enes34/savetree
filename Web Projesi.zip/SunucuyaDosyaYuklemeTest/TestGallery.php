<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resim Galerisi</title>
</head>
<body>

<h2>Resim Galerisi</h2>

<?php
$uploadDirectory = 'upload/';
$uploadedImages = scandir($uploadDirectory);

foreach ($uploadedImages as $image) {
    if ($image != '.' && $image != '..') {
        // '{' karakterinin konumunu bul
        $accoladePosition = strpos($image, '{');

        if ($accoladePosition !== false) {
            // '{' karakterinden sonraki kısmı al
            $sonrakiKisim = substr($image, $accoladePosition + 1);

            // '}' karakterinin konumunu bul
            $kapatmaKarakteriPosition = strpos($sonrakiKisim, '}');

            if ($kapatmaKarakteriPosition !== false) {
                // '{' ve '}' arasındaki kısmı al
                $aradakiKisim = substr($sonrakiKisim, 0, $kapatmaKarakteriPosition);

                // '_' karakterine göre ayır
                $parcalanan = explode('_', $aradakiKisim);

                // Değerleri değişkenlere ata
                $resimIndex = $parcalanan[0];
                $BookOwnerID = $parcalanan[1];
                $BookID = $parcalanan[2];

                // Değerleri ekrana bastır
                echo 'Resim Index: ' . $resimIndex . '<br>';
                echo 'Book Owner ID: ' . $BookOwnerID . '<br>';
                echo 'Book ID: ' . $BookID . '<br>';
            } else {
                echo 'Metin içinde "}" karakteri bulunamadı.';
            }
        } else {
            echo 'Metin içinde "{" karakteri bulunamadı.';
        }
    }
}
?>

</body>
</html>
