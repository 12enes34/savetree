<?php
session_start();

if (isset($_GET['TraderID'])) {
  $GiverId = intval(trim($_GET['TraderID']));
  $KitapID = intval(trim($_GET['KitapID']));
    
}

        




          if (isset($_SESSION['ID'])) {
            // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
            $ReciverId = $_SESSION['ID'];//talep edenin id si
           $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  
            // SQL sorgusunu hazırlayın
            $query = "SELECT * FROM takastalebi WHERE BookGiverID = ? AND BookReceivedID = ? AND BookID = ?";
            $stmt = mysqli_prepare($conn, $query);
            
            // Değişkenleri bağlayın ve sorguyu çalıştırın
            mysqli_stmt_bind_param($stmt, "iii", $GiverId, $ReciverId, $KitapID);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) > 0) {
                echo 'boyle bir talep var zaten';
                
            }
            else{


            $query = "INSERT INTO takastalebi (BookGiverID , BookReceivedID ,BookID, Confirmation) VALUES (?, ?, ?, 0)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "iii", $GiverId, $ReciverId, $KitapID);
            mysqli_stmt_execute($stmt);
                        if ($result) {
                            echo 'sorgu basarili';
                        }
                  
                else {
                  echo 'Sorgu hatası: ' . mysqli_error($conn);
              }
          
            }
             // Header fonksiyonu buraya yerleştirilmeli, ancak öncesinde çıktı olmamalıdır.
    header('Location: KitapSayfa.php?BookID='.$KitapID);
    exit; // Yönlendirme yaptıktan sonra kodun devamını çalıştırmamak için exit kullanın.
        }


        
          ?>
