
<?php
$idBook = trim($_GET['idBook']);
$conn = mysqli_connect('localhost', 'root', '', 'savetree_kitaptakasi');
$query = "DELETE FROM takastalebi WHERE BookID = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $idBook);
$result = mysqli_stmt_execute($stmt);
if ($result) {
    echo 'Çalıştı';
} else {
    echo 'Sorgu hatası: ' . mysqli_error($conn);
}
header('Location: KullaniciAnaSayfa.php');
exit; // Yönlendirme yaptıktan sonra kodun devamını çalıştırmamak için exit kullanın.
?>