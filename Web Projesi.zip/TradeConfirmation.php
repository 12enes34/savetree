
<?php
$tradeID = trim($_GET['tradeID']);
$TradeResult = trim($_GET['TradeResult']);
echo $TradeResult;
$conn = mysqli_connect('localhost', 'root', '', 'savetree_kitaptakasi');
$query = "UPDATE takastalebi SET Confirmation = ? WHERE ID = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ii", $TradeResult, $tradeID);
$result = mysqli_stmt_execute($stmt);
if ($result) {
    echo 'Çalıştı';
} else {
    echo 'Sorgu hatası: ' . mysqli_error($conn);
}
header('Location: KullaniciAnaSayfa.php');
exit; // Yönlendirme yaptıktan sonra kodun devamını çalıştırmamak için exit kullanın.
?>