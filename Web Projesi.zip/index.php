<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Save Tree</title>

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    
    
    <?php
session_start();
    ?>














    <?php


// Oturumda kullanıcı kimliği var mı kontrol et
if (isset($_SESSION['ID'])) {
    // Kullanıcı girişi yapılmışsa, ID'sini kullanarak ad ve soyadı çek
    $userId = $_SESSION['ID'];
    
   $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");      // Hazır ifade kullanarak sorguyu hazırla
    $query = "SELECT Name, Surname FROM kullanicilar WHERE ID = ?";
    $stmt = mysqli_prepare($conn, $query);

    // $userId değişkenini bağla
    mysqli_stmt_bind_param($stmt, "i", $userId);

    // Sorguyu çalıştır
    mysqli_stmt_execute($stmt);

    // Sonucu al
    $result = mysqli_stmt_get_result($stmt);


    if ($result) {
        $userInfo = mysqli_fetch_assoc($result);

        if ($userInfo) {
            
           
        } else {
            echo 'Kullanıcı bilgileri bulunamadı.';
        }
    } else {
        echo 'Sorgu hatası: ' . mysqli_error($conn);
    }
}
?>

   





      <style>
        .container {
    width: 75%;
    margin:auto;
    text-align: center;
    text-align-last: center;
    margin-top:25px; 
    
}



.box {
    width: 100%;
    display:inline-block;
    width: 256px;
    height: 420px;
    background-color: #ffffff;
    border: 2px solid;
    overflow: hidden;
    margin-left: 10px;
    margin-right:10px;
    margin-bottom: 10px;
    margin-top: 10px;
    text-align: center;
    transition: transform 0.3s; /* Hover'da geçiş efekti */
    
}
@media screen and (max-width: 720px) {
    .box {
        display:inline-block;
        width: 256px;
        height: 420px;
        background-color: #ffffff;
        border: 2px solid;
        margin-left: 10px;
        margin-right:10px;
        margin-bottom: 10px;
        margin-top: 10px;
        text-align: center;
        transition: transform 0.3s; /* Hover'da geçiş efekti */

    }
}

.box:hover {
    transform: scale(1.1); /* Hover'da büyütme efekti */
}

.imgdiv {
    width: 256px;
    height: 280px;
    border: 2px solid blue;
    margin: auto;
    display: flex;
    justify-content: center;
    align-items: center;
}

@media screen and (max-width: 720px) {
    .imgdiv {
        width: 144px;
        height: 146px;
        border: 2px solid blue;
        margin: auto;
        display: flex;
        justify-content: center;
        align-items: center;
    }
}
.imgdiv2 {
    width: 256px;
    height: 65px;
    margin: auto;
    display: flex;
    justify-content: center;
    align-items: center;
}

@media screen and (max-width: 720px) {
    .imgdiv2 {
        width: 144px;
        height: 46px;
        margin: auto;
        display: flex;
        justify-content: center;
        align-items: center;
    }
}
.p_tag {
    margin: auto;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: fantasy;
    font-size: 45px;
}
@media screen and (max-width: 720px) {
    .p_tag {   
        margin: auto;
        display: flex;
        justify-content: center;
        align-items: center;
        font-family: fantasy;
        font-size: 30px;}
}


@media screen and (max-width: 480px) {
    .header {
        min-height: 10px;
         /* Ekran genişliği 768 piksel veya daha küçükse font boyutunu 36 piksel yap */
    }
}

@media screen and (max-width: 700px) {
    .header {
        min-height: 50px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
} 
@media screen and (max-width: 900px) {
    .header {
        min-height: 60px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}


.logo{
    display: inline-block;
    padding: 0.5%;
    
    }

.logo2{
    
    padding: 10px;
    border: 1px solid #000;
    color: rgb(19, 202, 19);
    font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    font-size: 46px; /* Yazı boyutunu daha büyük bir değere ayarlayın */
    
    }
    .logo3 {

        padding: 10px;
        color: rgb(19, 202, 19);
        font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        font-size: 46px; /* Yazı boyutunu daha büyük bir değere ayarlayın */
        text-align: center;
    }
    
.logoWrite {
    font-weight: bold;
    font-size: 56px;
    color: #000;
}

@media screen and (max-width: 370px) {
    .logoWrite {
        font-size: 13px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}
@media screen and (max-width: 480px) {
    .logoWrite {
        font-size: 17px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}
@media screen and (max-width: 600px) {
    .logoWrite {
        font-size: 19px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}
@media screen and (max-width: 800px) {
    .logoWrite {
        font-size: 20px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}
@media screen and (max-width: 1000px) {
    .logoWrite {
        font-size: 38px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}


#logojpg{
    width: 128px;
}

@media screen and (max-width: 900px) {
    #logojpg {
        width: 64px; /* Ekran genişliği 768 piksel veya daha küçükse font boyutunu 36 piksel yap */
    }
}

@media screen and (max-width: 600px) {
    #logojpg {
        width: 48px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}

header img {
    width: 20px;
    height: auto;
    margin-top: 0px;
}


body, html {
    margin: 0;
    padding: 0;
    
    
}

.bannerlogo{
display: inline-block;
padding: 10px;
}


.banner2{
display: inline-block;
padding: 10px;
vertical-align: top;
}
.bannerWrite{
font-weight: bold;
font-size: 56px;
color: #000;
}


@media screen and (max-width: 768px) {
    .bannerWrite {
        font-size: 36px; /* Ekran genişliği 768 piksel veya daha küçükse font boyutunu 36 piksel yap */
    }
}

@media screen and (max-width: 480px) {
    .bannerWrite {
        font-size: 12px; /* Ekran genişliği 480 piksel veya daha küçükse font boyutunu 24 piksel yap */
    }
}


.deneme1{
    position: fixed;
    top: 10px;
    width: 100%;
    height: 200px;
    
    
    }

/*sliderin css i*/





.swiper {
    width: 256px;
    height: 400px;
  }

  .swiper-slide {
    text-align: center;
    font-size: 18px;
    background: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .swiper-slide img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }








  /*sliderin css i*/
.slider-container {
    display: inline-block;
    font: 19px sans-serif;
    margin: 0 auto;
    position: relative;
    width: 100%;
    max-width: 256px;
    height: 400px;
    overflow: hidden;
    border: 2px solid #ccc;
    white-space: nowrap;
    margin-left: 10px;
    margin-right:10px;
    margin-bottom: 10px;
    margin-top: 10px;
    transition: transform 0.3s;
  }
  


  
.slider-container:hover {
    transform: scale(1.1); /* Hover'da büyütme efekti */
    }


  .slayt {
    display: inline-block;
    width: 100%;
    box-sizing: border-box;
  }
  
  .slayt img{
    width: 256px;;
    height: 420px;
  }   
  
  .controls {
    position: absolute; /* fixed olarak değiştirin */
    bottom: 205px; /* İstediğiniz mesafeyi ayarlayın */
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    display: flex;
    justify-content: space-between;
    z-index: 1; /* Diğer öğelerin üzerinde olmasını sağlamak için z-index ekleyin */
    user-select: none;
  }
  
  .slider-forward,
  .slider-back {
    background-color: transparent;
    color: #006aff;
    text-decoration: none;
    cursor: pointer;
    font-size: 30px; /* Font boyutunu ayarlayın */
  }
  
  .slider-back {
    text-align: left;
  }
  
  .slider-forward {
    text-align: right;
  }
  
  


/*Alert CSS*/
.container {
    text-align: center;
    padding: 20px;
}

.popup {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 1001;
    font-size: 36px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Gölgelendirme efekti */

}

.popup-content {
    background-color: #aae1ea;
    margin: 10% auto;
    padding: 20px;
    width: 20%;
    border-radius: 18px; /* Kenarları yumuşatmak için değeri artırabilirsiniz */
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.3); /* Hafif bir gölgelendirme efekti */
    font-family:Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif
}

.close {
    color: #ff0000;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover {
    color: #f00; /* Kapatma butonunun üzerine gelindiğinde rengi */
}


*::before {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}



.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #333;
    color: #fff;
}

.logo img {
    max-width: 100px;
}

.quote {
    flex-grow: 1;
    margin: 0 20px;
    font-size: 28px;
    text-align: justify;
}
.buttons-container {
    text-align: center;
    display: block;
}

.CustomButton {
    padding: 10px;
    margin: 5px;
    font-size: 14px;
    cursor: pointer;
    background-color: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 12%; /* Yuvarlak şekil */
    text-align: center;
    position: relative; /* Animasyon için */
    overflow: hidden; /* Animasyon için */
}

.CustomButton {
    background-color: #3e3a3a;
}


.CustomButton:hover {
    background-color: #45a049;
    transform: scale(1.1); /* Büyüme efekti */
}


.CustomButton::before {
    content: ""; /* Animasyon için */
    position: absolute; /* Animasyon için */
    width: 100%; /* Animasyon için */
    height: 100%; /* Animasyon için */
    top: 0; /* Animasyon için */
    left: 0; /* Animasyon için */
    background: radial-gradient(circle, transparent 1%, #fff 15%); /* Animasyon için */
    transform: translateX(-150%); /* Animasyon için */
    transition: all 0.5s; /* Animasyon için */
}


.CustomButton:hover::before {
    transform: translateX(150%); /* Animasyon için */
}

.CustomButton::after {
    content: ""; /* İkon için */
    position: absolute; /* İkon için */
    width: 20px; /* İkon için */
    height: 20px; /* İkon için */
    top: 50%; /* İkon için */
    left: 50%; /* İkon için */
    transform: translate(-50%, -50%); /* İkon için */
    background-image: url("lock.png"); /* İkon için */
    background-size: cover; /* İkon için */
}






/*Contact me*/

* {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}
.body2 {
	height: 100vh;
	display: -webkit-box;
	display: -ms-flexbox;
	display: contents;
	-webkit-box-pack: center;
	-ms-flex-pack: center;
	justify-content: center;
	-webkit-box-align: center;
	-ms-flex-align: center;
	align-items: center;
	-webkit-perspective: 1000px;
	perspective: 1000px;
	-webkit-transform-style: preserve-3d;
	transform-style: preserve-3d;
	position: relative;
	background-color: #111;
	font-family: "Montserrat";
}

.containerContacMe {
	min-width: 700px;
	min-height: 450px;
	border-radius: 20px;
	position: relative;
	-webkit-transition: 1.5s ease-in-out;
	transition: 1.5s ease-in-out;
	transform-style: preserve-3d;
    
}

.ContacMeSide {
	position: absolute;
	text-align: center;
	width: 100%;
	height: 100%;
	padding: 20px 50px;
	color: #fff;
	transform-style: preserve-3d;
	backface-visibility: hidden;
	border-radius: 20px;
}
.ContacMeContent {
	transform: translatez(70px) scale(0.8);
	line-height: 1.5em;
    font-size: 35px;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    color: #000;
}
.ContacMeContent h1 {
	position: relative;
}
.ContacMeContent p {
	margin-top: 50px;
	line-height: 2em;
}
.ContacMeContent h1:before {
	content: "";
	position: absolute;
	bottom: -20px;
	height: 3px;
	background-color: #3e3;
	width: 70px;
	left: 50%;
	transform: translateX(-50%);
}
.ContacMefront {
	z-index: 2;
	background-size: 100vh;
	background-size: cover;
	background-image: url(resim/ContacWBgIMG.jpg);
}
.ContacMeback {
	background-color: #333;
	transform: rotateY(180deg);
	z-index: 0;
	padding-top: 10px;
	background-image: url(resim/ContacWBgIMG.jpg);
}
.containerContacMe:hover {
	-webkit-transform: rotateY(180deg);
	transform: rotateY(180deg);
}
form {
	text-align: left;
}
.ContacMeback h1 {
	margin: 0;
}
form label,
form input {
	display: block;
}
form input,
form textarea {
	background: transparent;
	border: 0;
	border-bottom: 2px solid #444;
	padding: 5px;
	width: 100%;
	color: #fff;
}
form label {
	margin: 15px 0;
}
form input[type="submit"] {
	display: block;
	width: auto;
	margin: 10px auto;
	padding: 5px 10px;
	border: 3px solid #555;
	border-radius: 4px;
	color: #fff;
	cursor: pointer;
}
/* my button style  */
.white-mode {
	text-decoration: none;
	padding: 7px 10px;
	background-color: #122;
	border-radius: 3px;
	color: #fff;
	transition: 0.35s ease-in-out;
	position: fixed;
	left: 15px;
	bottom: 15px;
	font-family: "Montserrat";
}

.white-mode:hover {
	background-color: #fff;
	color: #122;
}




*::selection {
    background-color: transparent;
    color: inherit;
}
















































      </style>
    
    










</head>
<body>

    <header>
        <div class="header">
            <div class="logo">
            <a href="index.php">
        <img id="logojpg" src="logo.png" alt="Logo">
    </a>
            </div>
            <div class="quote">
                What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another.
                Mahatma Gandhi
            </div>
            
<script>
    window.onresize = function() {
        var quoteDiv = document.getElementById("quote");
        if (window.innerWidth <= 600) {
            quoteDiv.innerText = "Save Tree";
        } else {
            quoteDiv.innerText = "What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves and to one another. Mahatma Gandhi";
        }
    };
</script>
            


            <div class="buttons-container">
                <button id='KullaniciGiris' class="CustomButton" onclick="handleButtonClick(1)">Kullanıcı Girişi</button>
                <button id='KayitOl' class="CustomButton" onclick="handleButtonClick(2)">Kayıt Ol</button>
                <button class="CustomButton" onclick="handleButtonClick(3)">Anasayfa</button>
                <?php
if (isset($_SESSION['ID'])) {

    if ($userInfo) {
        // Kullanıcı adı ve soyadını ekrana yazdır
       
        
        // Butonları tıklanamaz yap ve içlerine isim ve soyisim yaz
        echo '<script>';
        echo 'document.getElementById("KullaniciGiris").innerText = "'.$userInfo['Name'].' '.$userInfo['Surname'].'";';
        echo 'document.getElementById("KullaniciGiris").onclick = function() {
            window.location.href = "KullaniciAnaSayfa.php";
        };;';

        echo 'document.getElementById("KayitOl").innerText = "Cikis";';
        echo 'document.getElementById("KayitOl").onclick = function() {
            window.location.href = "Cikis.php";
        };;';

        echo '</script>';
    } else {
        echo 'Kullanıcı bilgileri bulunamadı.';
    }
}



?>
            </div>
        </div>
        
    </header>
<script>function BookTypeClick(BookType){
    window.location.href = 'KitaplarListesi.php?BookType='+BookType;

}</script>

    
    <div class="container">



        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Ani Kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Otobiyografi.png" onclick="BookTypeClick('Otobiyografi')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/KisiselAnilar.png" onclick="BookTypeClick('Kisisel Anilar')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Hatiratlar.png" onclick="BookTypeClick('Hatiratlar')" alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Romanlar.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Ask.png" onclick="BookTypeClick('Ask')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/BilimKurgu.png" onclick="BookTypeClick('BilimKurgu')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Macera.png" onclick="BookTypeClick('Macera')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Polisiye.png" onclick="BookTypeClick('Polisiye')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Tarihi.png" onclick="BookTypeClick('Tarihi')" alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Hikaye Kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Fantastik.png" onclick="BookTypeClick('Fantastik')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Gerilim.png" onclick="BookTypeClick('Gerilim')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/KisaHikayeler.png" onclick="BookTypeClick('Kisa Hikayeler')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/UzunHikayeler.png" onclick="BookTypeClick('Uzun Hikayeler')" alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Gezi kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/GeziAnilari.png" onclick="BookTypeClick('Gezi Anilari')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/SeyahatGunlukleri.png" onclick="BookTypeClick('Seyahat Gunlukleri')" alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Siir kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Dramatik.png" onclick="BookTypeClick('Dramatik')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Epik.png" onclick="BookTypeClick('Epik')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Lirik.png" onclick="BookTypeClick('Lirik')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Modern.png" onclick="BookTypeClick('Modern')" alt=""></div>

                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Biyografi Kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/BilimInsani.png" onclick="BookTypeClick('Bilim insani')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/SanatciBiyografisi.png" onclick="BookTypeClick('Sanatci biyografsi')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/unlukisiler.png" onclick="BookTypeClick('Unlu Kisiler')" alt=""></div>

                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Din Kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/DiniHikayeler.png" onclick="BookTypeClick('Dini Hikayeler')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Dini Yorum.png" onclick="BookTypeClick('Dini Yorum')" alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Bilgi Kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Ekonomi.png" onclick="BookTypeClick('Ekonomi')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/felsefe.png" onclick="BookTypeClick('Felsefe')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Populer bilim.png" onclick="BookTypeClick('Populer bilim')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/psikoloji.png" onclick="BookTypeClick('Psikoloji')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/sosyoloji.png" onclick="BookTypeClick('Sosyoloji')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Teknoloji.png" onclick="BookTypeClick('Teknoloji')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/Tarih.png" onclick="BookTypeClick('Tarih')" alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Masal Kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/KlasikMasallar.png" onclick="BookTypeClick('Klasik Masallar')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/FablMasallar.png" onclick="BookTypeClick('Fabl Masallar')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/FantastikMasallar.png"  onclick="BookTypeClick('Fantastik Masallar')"alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    

        <div class="slider-container">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img onclick="openPopup()" src="resim/Egitim Kitaplari.png" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/TemelDersKitaplari.png" onclick="BookTypeClick('Temel Ders Kitaplari')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/YabanciDilKitaplari.png" onclick="BookTypeClick('Yabanci Dil Kitaplari')" alt=""></div>
                  <div class="swiper-slide"><img src="resim/Web projesi tasarimlari/EgitimTeknolojisiKitaplari.png" onclick="BookTypeClick('Egitim Teknolojisi Kitaplari')" alt=""></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    
        








        <div class="container">
            <div id="popup" class="popup">
                <div class="popup-content">
                    <span class="close" onclick="closePopup()">&times;</span>
                    <p>Lütfen slider den kitap seçin!</p>
                </div>
            </div>
        </div>

        
        <div class="body2">

            <div class="containerContacMe">
                <div class="ContacMefront ContacMeSide">
                    <div class="ContacMeContent">
                        <h1>SAVE TREE</h1>
                        <p>
                            Save Tree, kitap takası aracılığıyla sadece bilgi paylaşımını teşvik etmekle kalmaz, aynı zamanda kullanılmayan kitapların atılmasını önleyerek ağaçları kurtarmayı hedefler, bu da çevre dostu bir yaklaşım benimser ve kaynakları sürdürülebilir bir şekilde kullanır.
                        </p>
                    </div>
                </div>
                <div class="ContacMeback ContacMeSide">
                    <div class="ContacMeContent">
                        <h2>Bizimle iletişime geç</h2>
                        <form>
                            <label>Adınız :</label>
                            <input type="text">
                            <label>Mail adresiniz :</label>
                            <input type="text">
                            <label>Mesajınız :</label>
                            <textarea ></textarea>
                            <input style="width: 100px; height: 50px;font-size: 20px; color: black;" type="submit" value="Gönder">
                        </form>
                    </div>
                </div>
            
            </div>
            
        </div>


          



        

            

        
    </div>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>


    <script>
        var swiper = new Swiper(".mySwiper", {
          pagination: {
            el: ".swiper-pagination",
            type: "progressbar",
          },
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
        });
      </script>



    <script>
        

function openPopup() {
    document.getElementById("popup").style.display = "block";
    setTimeout(closePopup, 1500); // 1000 milisaniye (1 saniye) sonra closePopup fonksiyonunu çağır
}

function closePopup() {
    document.getElementById("popup").style.display = "none";
}






        "use strict";

        function sonrakiSlayt(sliderID) {
            var slider = document.getElementById(sliderID);
            var slayt = slider.querySelectorAll(".slayt");
            var slaytSayisi = slayt.length;
            var slaytNo = Array.from(slayt).findIndex(function(s) {
                return s.style.display === "block";
            });

            slaytNo++;
            slaytGoster(slaytNo, slider);
        }

        function oncekiSlayt(sliderID) {
            var slider = document.getElementById(sliderID);
            var slayt = slider.querySelectorAll(".slayt");
            var slaytSayisi = slayt.length;
            var slaytNo = Array.from(slayt).findIndex(function(s) {
                return s.style.display === "block";
            });

            slaytNo--;
            slaytGoster(slaytNo, slider);
        }

        function slaytGoster(slaytNumarasi, slider) {
    var slayt = slider.querySelectorAll(".slayt");
    var slaytSayisi = slayt.length;
    var slaytNo = slaytNumarasi;

    if (slaytNumarasi >= slaytSayisi) slaytNo = 0;
    if (slaytNumarasi < 0) slaytNo = slaytSayisi - 1;

    for (var i = 0; i < slaytSayisi; i++) {
        slayt[i].classList.remove("active"); // Aktif sınıfını kaldır
        slayt[i].style.display = "none";
    }

    slayt[slaytNo].classList.add("active"); // Aktif sınıfı ekle
    slayt[slaytNo].style.display = "block";
}

function handleButtonClick(buttonType) {
        if (buttonType === 1) {
            // Kullanıcı Girişi butonuna tıklandığında yönlendirme yap
            window.location.href = 'kullaniciGirisEkrani.php?newValue=Giris'; // Yönlendirilecek sayfanın URL'sini belirtin
        } else if (buttonType === 2) {
            window.location.href = 'kullaniciGirisEkrani.php?newValue=Kayit';
            
        } else if (buttonType === 3) {
            window.location.href = 'index.php';

            
        }


    }


    </script>


</body>

</html>
