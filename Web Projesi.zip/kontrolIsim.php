<?php
// Veritabanı bağlantısı
$conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  // Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}

// AJAX isteğinden kullanıcı adını al
$username = $_POST['username'];

// Parametreli sorgu kullanarak SQL sorgusunu hazırla
$sql = "SELECT * FROM kullanicilar WHERE Username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username); // "s" string tipi olduğunu belirtir
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Kullanıcı adı mevcut ise geriye hata mesajı döndür
    echo "Bu kullanıcı adı zaten alınmış.";
} 
else if(strlen($username)<8 || strlen($username)>30){
    echo "Kullanıcı adı karekteri yetersiz.";
}

else {
    // Kullanıcı adı mevcut değil ise geriye başarılı mesajı döndür
    echo "Bu kullanıcı adı kullanılabilir.";
}

$conn->close();

?>
