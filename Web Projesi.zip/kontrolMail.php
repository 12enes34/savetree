<?php
// Veritabanı bağlantısı
$conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");  // Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}

// AJAX isteğinden mail adresini al
$mail = $_POST['mail'];

// Mail adresinin belirli bir formata sahip olup olmadığını kontrol et
if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
    // Belirli bir formata sahip değilse geriye hata mesajı döndür
    echo "Lütfen geçerli bir mail adresi giriniz.";
    exit; // Kodun devamını çalıştırmamak için çıkış yap
}

// Parametreli sorgu kullanarak SQL sorgusunu hazırla
$sql = "SELECT * FROM kullanicilar WHERE Mail = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $mail); // "s" string tipi olduğunu belirtir
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Mail adresi mevcut ise geriye hata mesajı döndür
    echo "Bu mail adresi zaten alınmış.";
} else {
    // Mail adresi mevcut değil ise geriye başarılı mesajı döndür
    echo "Bu mail adresi kullanılabilir.";
}

$conn->close();
?>
