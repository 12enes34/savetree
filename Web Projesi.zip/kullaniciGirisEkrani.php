<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      
        <!-- Font online-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
      
<!--        Animate.css-->
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
                
                                
        
        <!-- Google JQuery CDN -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#username').keyup(function(){
                var username = $(this).val();
                
                $.post('kontrolIsim.php', {'username':username}, function(data){
                    $('#usernameMesaj').html(data);
                    var yeniDegisken = data;

                    if (yeniDegisken == 'Bu kullanıcı adı zaten alınmış.') {
                        var button = document.getElementById("signup-form-submit");
                        console.log(yeniDegisken);
                        button.setAttribute("disabled", true);

                    } else if (yeniDegisken == 'Kullanıcı adı karekteri yetersiz.') {

                        var button = document.getElementById("signup-form-submit");
                        console.log(yeniDegisken);
                        button.setAttribute("disabled", true);
                        
                    } else if (yeniDegisken == 'Bu kullanıcı adı kullanılabilir.') {

                        var button = document.getElementById("signup-form-submit");
                        console.log(yeniDegisken);
                        button.removeAttribute("disabled");

                    }

                });
            });
        });
        $(document).ready(function(){
            $('#mail').keyup(function(){
                var mail = $(this).val();
                $.post('kontrolMail.php', {'mail':mail}, function(data){
                    $('#mailMesaj').html(data);
                    var yeniDegisken = data;

                    if (yeniDegisken == 'Bu mail adresi zaten alınmış.') {
                        var button = document.getElementById("signup-form-submit");
                        console.log(yeniDegisken);
                        button.setAttribute("disabled", true);
                    } else if (yeniDegisken == 'Bu mail adresi kullanılabilir.') {
                        var button = document.getElementById("signup-form-submit");
                        console.log(yeniDegisken);
                        button.removeAttribute("disabled");
                    }
                    
                });
            });
        });
    </script>
        <style>

* {
    margin: 0;
    padding: 0;
}

html{
    width: 100%;
    height: 100%;
}

body {
    background: #e5e5e5;
    width: 100%;
    height: 100%;
    text-align: center;
    font-family: 'Open Sans', sans-serif;
    font-weight: 600;
    letter-spacing: 1px;
}

.panel{
    min-width: 23%;
    width: 100%;
    height: 100%;
    background:url('https://cdn1.epicgames.com/ue/product/Screenshot/Screenshot07-1920x1080-7ef40baa07af600e271c0ab654afb443.jpg?resize=1&w=1920')  #ffffff;
    background-repeat:no-repeat;
    background-position: top center;
    background-size: cover;
    margin:0% auto 0px;
    overflow: auto;
}

.panel::-webkit-scrollbar {
    width: 0px; /* Genişlik */
    height: 0px; /* Yükseklik */
}




.shadow1{
	-webkit-box-shadow:  0 20px 15px -15px rgba(119, 119, 119, 0.85);
	   -moz-box-shadow:  0 20px 15px -15px rgba(119, 119, 119, 0.85);
	        box-shadow:  0 40px 30px -30px rgba(119, 119, 119, 0.85);
}


form{
    height: 100%;
    padding: 50px;
}

.panel-switch{
    text-align: center;
    margin-top: 30px;
}

.panel-switch button{
    display: inline-block;
    width: 100px;
    height: 40px;
    background: #f03699;
    margin: 0px 10px 50px;
    border: none;
    color: #fff;
    font-family: 'Open Sans', sans-serif;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 2px;
    font-size: 0.8em;
    transition: background-color 0.2s ;
    
}

.panel-switch button:active{
    background: #b52773;
    color: #c9c9c9;
}

.active-button{
    opacity: 0.5;
}

button , .button , a {
    cursor: pointer;
}

form h1{
    color: #fff;
    font-family: 'Open Sans', sans-serif;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 4px;
    margin: 50px 0;
    font-size: 1.7em;
}

fieldset{
    border: none;
}


.animate1 , .animate2 , .animate3 , .animate4 , .animate5 , .animate6 , .animate7 {
    -webkit-animation-duration: 2s;
    -moz-animation-duration: 2s;
    
}

.animate1
{
    -webkit-animation-delay: 0.2s;
    -moz-animation-delay: 0.2s;
}

.animate2
{
    -webkit-animation-delay: 0.7s;
    -moz-animation-delay: 0.7s;
}

.animate3
{
    -webkit-animation-delay: 1.1s;
    -moz-animation-delay: 1.1s;
}

.animate4
{
    -webkit-animation-delay: 1.5s;
    -moz-animation-delay: 1.5s;
}

.animate5
{
    -webkit-animation-delay: 2.2s;
    -moz-animation-delay: 2.2s;
}
.animate6
{
    -webkit-animation-delay: 2.6s;
    -moz-animation-delay: 2.6s;
}

.animate7
{
    -webkit-animation-delay: 3.0s;
    -moz-animation-delay: 3.0s;
}

@-webkit-keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 100%, 0);
    transform: translate3d(0, 100%, 0);
  }

  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 100%, 0);
    transform: translate3d(0, 100%, 0);
  }

  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

fieldset input{
    background: rgba(0, 0, 0, 0.7);
    border: none;
    border-radius: 5em;
    height: 30px;
    width: 80%;
    margin: 10px 0;
    padding: 5px;
    text-indent: 10px;
    color: #fff;
    font-weight: 600;
}

fieldset input::placeholder {
    color: #c7c6c6;
}


fieldset input:focus {
    border: 1px solid rgba(0, 0, 0, 0.2);
    border-radius: 5em;
    margin: 9px 0;
}

.login_form{
    position: relative;
    bottom:0;
    width: 70%;
    height: 4em;
    margin-top: 150px;
    border: none;
    border-radius: 10em;
    background: #f03699;
    color: #fff;
    font-family: 'Open Sans', sans-serif;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 2px;
    z-index: 1;
    
    transition: background-color 0.2s ;
}

#login-form-submit:active{
    background: #b52773;
    color: #c9c9c9;
    
}


p , a{
    margin: 0;
    padding: 0;
}

a{
    color: #898787;
    font-size: 0.7em;
    text-decoration: none;
}

.hidden{
    display: none;
}

*::selection {
    background-color: transparent;
    color: inherit;
}

        </style>



    </head>
    <body>
        
    <div class="panel shadow1">
    <form class="login-form" action="KullaniciKayit.php" method="post">
        <div class="panel-switch animated fadeIn">
            <button type="button" id="sign_up" class="active-button">Sign Up</button>
            <button type="button" id="log_in" class="" disabled>Log in</button>
        </div>
        <h1 class="animated fadeInUp animate1" id="title-login">Welcome Back !</h1>
        <h1 class="animated fadeInUp animate1 hidden" id="title-signup">Welcome !</h1>
        <fieldset id="login-fieldset">
            <input class="login animated fadeInUp animate2" id="idusernameLog" name="usernameLog" type="textbox" required placeholder="Username" value="">
            <input class="login animated fadeInUp animate3" id="passwordLog" name="passwordLog" type="password" required placeholder="Password" value="">
        </fieldset>
        <fieldset id="signup-fieldset" class="hidden">

            <span id="usernameMesaj"></span><br> <!-- Bu span, kullanıcı adı kontrol mesajlarını gösterecek -->
            <span id="mailMesaj"></span><br> <!-- Bu span, kullanıcı adı kontrol mesajlarını gösterecek -->
            <span style="color:red" id="sifreUyari"></span><br> <!-- Bu span, kullanıcı adı kontrol mesajlarını gösterecek -->

            <input class="login animated fadeInUp animate1" name="username" id="username" type="textbox" required minlength="8" maxlength="30" placeholder="Username (Min 8, Max 30 characters)" value="">
            <input type="email"   class="login animated fadeInUp animate2" id="mail" name="mail" required placeholder="Mail" value="" required >
            <input class="login animated fadeInUp animate3" name="password" id="password" type="password" required minlength="4" maxlength="12" placeholder="Password (Min 4, Max 12 characters)" value="">
            <input class="login animated fadeInUp animate4" name="name" id="idname" type="textbox" placeholder="Name" required value="">
            <input class="login animated fadeInUp animate5" name="surname" id="idsurname" type="textbox" placeholder="Surname" required value="">
            <input class="login animated fadeInUp animate6" name="number" id="idnumber" type="tel" placeholder="Number" pattern="^\+90[0-9]{10}$" title="Please enter a valid Turkish phone number starting with +90 and total of 11 digits." required>
            <input class="login animated fadeInUp animate7" name="city" id="idcity" type="textbox" placeholder="Your City" required value="">
        </fieldset>
        <input type="submit" id="login-form-submit" class="login_form button animated fadeInUp animate7" value="Log in">
        <input type="submit" id="signup-form-submit" class="login_form button animated fadeInUp animate7 hidden" value="Sign up ">
        <p><a id="lost-password-link" href="SifreSifirlama.php" class="animated fadeIn animate7" style="color: lightcoral;" onclick="openInNewTab(this.href); return false;">I forgot my login or password (!)</a></p>

<script>
    function openInNewTab(url) {
        var win = window.open(url, '_blank');
        win.focus();
    }

    $(document).ready(function() {
    $('#password').keyup(function() {
        var password = $(this).val();
        if (password.length < 4) {
            $('#passwordMesaj').text("Şifre en az 4 karakter olmalıdır.");
            $('#signup-form-submit').prop('disabled', true);
            document.getElementById("sifreUyari").innerHTML = "Şifreniz gerekli şartları sağlamamaktadır";

        } else {
            document.getElementById("sifreUyari").innerHTML = "";
            $('#passwordMesaj').text("");
            $('#signup-form-submit').prop('disabled', false);
        }
    });
});





</script>
    </form>
</div>

        

        <script>$(document).ready(function(){



            //--------- change color value of the form text/password inputs -----
            
                const textInputs =  $("input[type='textbox']");
                const passwordsInputs =  $("input[type='password']");
                //--------- Login screen swicth -----
            
                $("button").click(function(event){  //  prevent buttons in form to reload
                    event.preventDefault();
                });
                
                $("a").click(function(event){  //  prevent 'a' links in form to reload
                    event.preventDefault();
                });
            
                $("#sign_up").click(function(){ // when click Sign Up button, hide the Log In elements, and display the Sign Up elements
                    $("#title-login").toggleClass("hidden",true);
                    $("#login-fieldset").toggleClass("hidden",true);
                    $("#login-form-submit").toggleClass("hidden",true);
                    $("#lost-password-link").toggleClass("hidden",true);
                    $("#sign_up").toggleClass("active-button",false);
                    $("#log_in").removeAttr("disabled");
                    
                    $("#title-signup").toggleClass("hidden",false);
                    $("#signup-fieldset").toggleClass("hidden",false);
                    $("#signup-form-submit").toggleClass("hidden",false);
                    $("#log_in").toggleClass("active-button",true);
                    $("#sign_up").prop('disabled', true);

                });
                
                $("#log_in").click(function(){ // when click Log In button, hide the Sign Up elements, and display the Log In elements
                    $("#title-login").toggleClass("hidden",false);
                    $("#login-fieldset").toggleClass("hidden",false);
                    $("#login-form-submit").toggleClass("hidden",false);
                    $("#lost-password-link").toggleClass("hidden",false);
                    $("#sign_up").toggleClass("active-button",true);
                    $("#log_in").prop('disabled', true);
                    
                    $("#title-signup").toggleClass("hidden",true);
                    $("#signup-fieldset").toggleClass("hidden",true);
                    $("#signup-form-submit").toggleClass("hidden",true);
                    $("#log_in").toggleClass("active-button",false);
                    $("#sign_up").removeAttr("disabled");

                });

                $("#login-form-submit").click(function () {
    var form = $("form.login-form");
    var allFieldsFilled = true;

    // İlgili input nesnesinin id'sini belirleyin
    //var requiredInput = $("#login-inputId");

    // İlgili input nesnesinin değerini kontrol edin
    if ($("#idusernameLog").val() === '') {
        allFieldsFilled = false;
    }
    if ($("#passwordLog").val() === '') {
        allFieldsFilled = false;
    }

    if (allFieldsFilled) {
        form.attr("action", "KullaniciGiris.php");
        form.submit();
    } else {

    }
});



$("#signup-form-submit").click(function () {
    var form = $("form.login-form");
    var allFieldsFilled = true;

    // İlgili input nesnesinin id'sini belirleyin
    //var requiredInput = $("#inputId");

    // İlgili input nesnesinin değerini kontrol edin
    if ($("#username").val() === '') {
        allFieldsFilled = false;
    }
    if ($("#mail").val() === '') {
        allFieldsFilled = false;
    }
    if ($("#idpassword").val() === '') {
        allFieldsFilled = false;
    }
    if ($("#idname").val() === '') {
        allFieldsFilled = false;
    }
    if ($("#idsurname").val() === '') {
        allFieldsFilled = false;
    }
    if ($("#idnumber").val() === '') {
        allFieldsFilled = false;
    }
    if ($("#idcity").val() === '') {
        allFieldsFilled = false;
    }


    if (allFieldsFilled) {
        form.attr("action", "KullaniciKayit.php");
        form.submit();
    } else {
        
    }
});


    });

        const urlParams = new URLSearchParams(window.location.search);
        const valueToSet = urlParams.get('newValue');
        console.log(valueToSet);

        
        if (valueToSet === "Kayit") {
            
            $("#title-login").toggleClass("hidden",true);
                    $("#login-fieldset").toggleClass("hidden",true);
                    $("#login-form-submit").toggleClass("hidden",true);
                    $("#lost-password-link").toggleClass("hidden",true);
                    $("#sign_up").toggleClass("active-button",false);
                    $("#log_in").removeAttr("disabled");
                    
                    $("#title-signup").toggleClass("hidden",false);
                    $("#signup-fieldset").toggleClass("hidden",false);
                    $("#signup-form-submit").toggleClass("hidden",false);
                    $("#log_in").toggleClass("active-button",true);
                    $("#sign_up").prop('disabled', true);

                ;
           
            }
            

        else if(valueToSet === "Giris") {

                    $("#title-login").toggleClass("hidden",false);
                    $("#login-fieldset").toggleClass("hidden",false);
                    $("#login-form-submit").toggleClass("hidden",false);
                    $("#lost-password-link").toggleClass("hidden",false);
                    $("#sign_up").toggleClass("active-button",true);
                    $("#log_in").prop('disabled', true);
                    
                    $("#title-signup").toggleClass("hidden",true);
                    $("#signup-fieldset").toggleClass("hidden",true);
                    $("#signup-form-submit").toggleClass("hidden",true);
                    $("#log_in").toggleClass("active-button",false);
                    $("#sign_up").removeAttr("disabled");







            }

            
            </script>
    </body>
</html>