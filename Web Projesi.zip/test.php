<?php 

                // Kullanicinin sahip oldugu kitaplar listesi
                $id = 6;

               $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");                  $query = "SELECT * FROM kitaplar WHERE BookOwnerID = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $Trade_result = mysqli_stmt_get_result($stmt);

                $listeKullaniciKitaplari = array();//listem

                    if ($Trade_result) {
                        echo "kullanicinin sahip oldugu kitaplar \n";
                        while ($row = mysqli_fetch_assoc($Trade_result)){
                            
                    
                            $listeKullaniciKitaplari[] = $row['ID'];
                        }
                    }
                
print_r($listeKullaniciKitaplari);


                                           

?>








<?php 

$id = 6; // kitap sahibinin id si

           $conn = mysqli_connect("localhost", "savetree_admin", "Xenesx1234", "savetree_kitaptakasi");              $query = "SELECT * FROM takastalebi WHERE BookGiverID = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);
            $Trade_result = mysqli_stmt_get_result($stmt);

            $listeKullaniciniTakasIstegiGelenKitaplari = array();//listem kulalnincin takas istegi gelen kitaplarinin takas istekleri


                        if ($Trade_result) {
                            echo 'Kullanincinin takas istegi gelen kitaplari';
                            while ($row = mysqli_fetch_assoc($Trade_result)){


                              
                                $listeKullaniciniTakasIstegiGelenKitaplari[] = $row['BookID'];


                            }
                        }
                
print_r($listeKullaniciniTakasIstegiGelenKitaplari);


?>




<?php 

$id = 6; // kitap sahibinin id si

$query = "SELECT * FROM takastalebi WHERE BookReceivedID = ?";
                    $stmt = mysqli_prepare($conn, $query);
                    mysqli_stmt_bind_param($stmt, "i", $id);
                    mysqli_stmt_execute($stmt);
                    $Trade_result = mysqli_stmt_get_result($stmt);

                    $listeKullanicininTakasIstegiVerdigiKitaplar = array();//Kullanincinin takas istegi verdigi kitaplarin id leri

                    if ($Trade_result) {
                        echo 'Kullanincinin takas istegi verdigi kitaplar';

                        while ($row = mysqli_fetch_assoc($Trade_result)){

                            $listeKullanicininTakasIstegiVerdigiKitaplar[] = $row['BookID'];



                        }
                    }



print_r($listeKullanicininTakasIstegiVerdigiKitaplar);


?>




<?php 

$SahipOlunanAdresi = array();
$TakasdakiAdresi = array();
$TakasIstedigiAdresi = array();

$en_uzun_dizi = $listeKullaniciKitaplari;

$uploadDirectory = 'upload/';
$uploadedImages = scandir($uploadDirectory);


if (count($listeKullaniciniTakasIstegiGelenKitaplari) > count($en_uzun_dizi)) {
    $en_uzun_dizi = $listeKullaniciniTakasIstegiGelenKitaplari;
}
if (count($listeKullanicininTakasIstegiVerdigiKitaplar) > count($en_uzun_dizi)) {
    $en_uzun_dizi = $listeKullanicininTakasIstegiVerdigiKitaplar;
}
echo '<br> EN UZUN DIZI <br>';
print_r($en_uzun_dizi);
foreach ($uploadedImages as $image) {

    if ($image != '.' && $image != '..') {

        // '{' karakterinin konumunu bul
        $accoladePosition = strpos($image, '{');

        if ($accoladePosition !== false) {
            // '{' karakterinden sonraki kısmı al
            $sonrakiKisim = substr($image, $accoladePosition + 1);

            // '}' karakterinin konumunu bul
            $kapatmaKarakteriPosition = strpos($sonrakiKisim, '}');

            if ($kapatmaKarakteriPosition !== false) {
                // '{' ve '}' arasındaki kısmı al
                $aradakiKisim = substr($sonrakiKisim, 0, $kapatmaKarakteriPosition);

                // '_' karakterine göre ayır
                $parcalanan = explode('_', $aradakiKisim);

                // Değerleri değişkenlere ata
                $resimIndex = $parcalanan[0];
                $BookOwnerID = $parcalanan[1];
                $BookID = $parcalanan[2];
                
              

                if($resimIndex==0){
                    echo'<br> KITAP ID:'.$BookID.'RESIM INDEX:'.$resimIndex.'<br>';
               
                    
                    //En uzun dizideki tum elamanlar bitene kadar sirayla hepsini tarar
                    foreach ($en_uzun_dizi as $eleman) {
                        echo '<br>'.'SU ANLIK ELAMAN:'.$eleman.'<br>';

                        
                        if(in_array($BookID, $listeKullaniciniTakasIstegiGelenKitaplari) && in_array($BookID, $listeKullaniciKitaplari)){
                            $TakasdakiAdresi[] = $uploadDirectory . $image;
                            $SahipOlunanAdresi[] = $uploadDirectory . $image;//kitabin adresi olacak
                            break;
                            
                        }


                        if(in_array($BookID, $listeKullaniciKitaplari)){
                            $SahipOlunanAdresi[] = $uploadDirectory . $image;//kitabin adresi olacak
                            echo'Kullanici kitabina eklendi :'.$BookID;
                            break;
                        }

                        if(in_array($BookID, $listeKullaniciniTakasIstegiGelenKitaplari)){
                            $TakasdakiAdresi[] = $uploadDirectory . $image;
                            echo'Takas istegi gelene eklendi :'.$BookID;
                            break;
                        }




                        if(in_array($BookID, $listeKullanicininTakasIstegiVerdigiKitaplar)){
                            $TakasIstedigiAdresi[] = $uploadDirectory . $image;
                            echo 'Takas istegi verdigi kitaplara eklendi :'.$BookID ;
                            break;
                        }

                     
                        
                    }

                }





                
                
                
                

                // Değerleri ekrana bastır
               
            } else {
                echo 'Metin içinde "}" karakteri bulunamadı.';
            }
        } else {
            echo 'Metin içinde "{" karakteri bulunamadı.';
        }

        // burasi resimIndex == 0 olu
       
    
    }
}


echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';


print_r($SahipOlunanAdresi);
echo '<br>';
echo '<br>';

echo '<br>';

echo '<br>';

echo '<br>';

print_r($TakasdakiAdresi);
echo '</br>';
echo '<br>';

echo '<br>';

echo '<br>';


echo '<br>';

echo '<br>';

print_r($TakasIstedigiAdresi);






?>