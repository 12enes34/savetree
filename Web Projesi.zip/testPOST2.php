<?php 
$email = $_POST['email'];
echo $email;

?>
