<?php
// update.php
session_start();

// Eğer gerekli parametreler gelmediyse işlem yapma
if (!isset($_GET['Name'], $_GET['Surname'], $_GET['Mail'], $_GET['Username'], $_GET['PhoneNumber'], $_GET['City'])) {
    // Hata mesajı gönder
    echo "Gerekli parametreler eksik.";
    exit;
}

// Verileri al sikinti olursa trim() fonksiyonunu kaldir
$name = trim($_GET['Name']);
$surname = trim($_GET['Surname']);
$mail = trim($_GET['Mail']);
$username = trim($_GET['Username']);
$phoneNumber = trim($_GET['PhoneNumber']);
$city = trim($_GET['City']);
$id = trim($_SESSION['ID']);

// Veritabanına bağlan
$conn = mysqli_connect('localhost', 'root', '', 'savetree_kitaptakasi');
$conn = mysqli_connect('localhost', 'savetree_admin', 'Xenesx1234', 'savetree_kitaptakasi');

// SQL sorgusunu hazırla
$query = "UPDATE kullanicilar SET Name = ?, Surname = ?, Mail = ?, Username = ?, PhoneNumber = ?, City = ? WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);

// Parametreleri bağla
mysqli_stmt_bind_param($stmt, "ssssssi", $name, $surname, $mail, $username, $phoneNumber, $city, $id);

// Sorguyu çalıştır
$result = mysqli_stmt_execute($stmt);

// Sonucu kontrol et
if ($result) {
    echo "Güncelleme başarılı.";
} else {
    echo "Güncelleme başarısız: " . mysqli_error($conn);
}

// Bağlantıyı kapat
mysqli_close($conn);
header('Location: KullaniciAnaSayfa.php');
exit; // Yönlendirme yaptıktan sonra kodun devamını çalıştırmamak için exit kullanın.
?>
